import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView, StatusBar, StyleSheet,
  KeyboardAvoidingView, Platform, Image, Linking, Modal,
} from 'react-native';

// تخزين بسيط بدون مكتبات إضافية (يعمل على الويب، وفي غيره يبقى في الذاكرة)
const mem = {};
const Store = {
  async get(k) {
    try { if (typeof localStorage !== 'undefined') return localStorage.getItem(k); } catch (e) {}
    return mem[k] === undefined ? null : mem[k];
  },
  async set(k, v) {
    try { if (typeof localStorage !== 'undefined') { localStorage.setItem(k, v); return; } } catch (e) {}
    mem[k] = v;
  },
};

// ---------- حسابات المستخدمين (Firebase) ----------
// الصق هنا القيمتين من إعدادات مشروعك في Firebase (ليستا سريتين)
const FB = { apiKey: 'AIzaSyBPZcX0vN-XEvGn_M7IAhmhPAPiLoEeKnM', projectId: 'zyvora-app-4033b' };
const AUTH_ON = !!FB.apiKey && FB.apiKey.indexOf('ضع') !== 0;
const AUTH_URL = 'https://identitytoolkit.googleapis.com/v1/accounts:';

async function fbAuth(path, body) {
  const r = await fetch(AUTH_URL + path + '?key=' + FB.apiKey, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const d = await r.json();
  if (!r.ok) throw new Error((d.error && d.error.message) || 'ERROR');
  return d;
}

async function fbRefresh(refreshToken) {
  const r = await fetch('https://securetoken.googleapis.com/v1/token?key=' + FB.apiKey, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=refresh_token&refresh_token=' + encodeURIComponent(refreshToken),
  });
  const d = await r.json();
  if (!r.ok) throw new Error('REFRESH');
  return {
    idToken: d.id_token,
    refreshToken: d.refresh_token,
    uid: d.user_id,
    expiresAt: Date.now() + (Number(d.expires_in) - 60) * 1000,
  };
}

const docUrl = uid =>
  'https://firestore.googleapis.com/v1/projects/' + FB.projectId + '/databases/(default)/documents/users/' + uid;

async function cloudLoad(s) {
  const r = await fetch(docUrl(s.uid), { headers: { Authorization: 'Bearer ' + s.idToken } });
  if (r.status === 404) return [];
  if (!r.ok) throw new Error('load ' + r.status);
  const d = await r.json();
  const v = d.fields && d.fields.chats && d.fields.chats.stringValue;
  return v ? JSON.parse(v) : [];
}

async function cloudSave(s, chats) {
  const list = chats.slice();
  let txt = JSON.stringify(list);
  while (txt.length > 900000 && list.length > 1) { list.pop(); txt = JSON.stringify(list); }
  const r = await fetch(docUrl(s.uid) + '?updateMask.fieldPaths=chats', {
    method: 'PATCH',
    headers: { Authorization: 'Bearer ' + s.idToken, 'Content-Type': 'application/json' },
    body: JSON.stringify({ fields: { chats: { stringValue: txt } } }),
  });
  if (!r.ok) throw new Error('save ' + r.status);
}

function mergeChats(a, b) {
  const map = {};
  [...(a || []), ...(b || [])].forEach(c => {
    if (c && c.id && (!map[c.id] || (c.updated || 0) > (map[c.id].updated || 0))) map[c.id] = c;
  });
  return Object.values(map).sort((x, y) => (y.updated || 0) - (x.updated || 0)).slice(0, 50);
}

function errKey(m) {
  const c = String(m || '');
  if (c.indexOf('EMAIL_EXISTS') === 0) return 'errEmailExists';
  if (/INVALID_LOGIN_CREDENTIALS|EMAIL_NOT_FOUND|INVALID_PASSWORD|MISSING_PASSWORD/.test(c)) return 'errBadLogin';
  if (c.indexOf('WEAK_PASSWORD') === 0) return 'errWeak';
  if (/INVALID_EMAIL|MISSING_EMAIL/.test(c)) return 'errEmail';
  if (c.indexOf('TOO_MANY_ATTEMPTS') === 0) return 'errMany';
  if (/OPERATION_NOT_ALLOWED|CONFIGURATION_NOT_FOUND/.test(c)) return 'errOp';
  return 'errGeneric';
}

// رابط الخادم (Cloudflare Worker)
const API_URL = 'https://zyvora-api.khalylmhmed88.workers.dev';

const C = {
  bg: '#FFFFFF', card: '#F3F5F9', border: '#E1E5EE',
  green: '#00E887', greenText: '#00995A', purple: '#873CFF',
  text: '#0B1020', muted: '#5F6B80', ink: '#04140C',
};

// ---------- نصوص الواجهة (العربية والإنجليزية جاهزتان، وبقية اللغات تُترجم تلقائياً) ----------
const UI_AR = {
  tagline: 'ذكاؤك، إمكانياتك بلا حدود',
  t0: 'حل مشكلتي', t1: 'حوّل فكرتي إلى مشروع', t2: 'سوّق لي', t3: 'افهم ما أراه', t4: 'خطّط بدلاً مني', t5: 'صمّم صورة أو عدّل صورة', t7: 'إدارة حياتك', t8: 'إنجاز المهام', t6: 'استوديو الأفلام الكرتونية',
  ph0: 'اشرح مشكلتك هنا...', ph1: 'اكتب فكرتك هنا...', ph2: 'أخبرني عن مشروعك أو منتجك...',
  ph3: 'أرفق صورة أو الصق نصاً...', ph4: 'اكتب هدفك والوقت المتاح...',
  ph5: 'صف الصورة أو الصورة المصغّرة، أو أرفق صورة لتعديلها...', ph6: 'اكتب فكرة فيلمك أو مشهدك الكرتوني...',
  generating: 'جارٍ التصميم...',
  ph7: 'مثال: ذكّرني بموعد الطبيب الخميس 5 مساءً، أو الصق بريداً لألخّصه وأكتب الرد...',
  linkCalendar: 'إضافة إلى التقويم', linkMail: 'فتح في البريد', linkMaps: 'فتح في الخرائط', linkFlights: 'البحث عن الرحلات', linkHotels: 'البحث عن الفنادق', linkOpen: 'فتح الرابط',
  authSub: 'سجّل الدخول لتُحفظ محادثاتك ومشاريعك وتعود إليها من أي جهاز.',
  email: 'البريد الإلكتروني', password: 'كلمة المرور (6 أحرف على الأقل)',
  signIn: 'تسجيل الدخول', signUp: 'إنشاء حساب', toSignUp: 'ليس لديك حساب؟ أنشئ حساباً', toSignIn: 'لديك حساب؟ سجّل الدخول',
  forgot: 'نسيت كلمة المرور؟', resetSent: 'أرسلنا رابط إعادة تعيين كلمة المرور إلى بريدك.', needEmail: 'اكتب بريدك أولاً.',
  logout: 'تسجيل الخروج', privacyCloud: 'محادثاتك ومشاريعك محفوظة في حسابك وتعود إليها من أي جهاز.',
  errEmailExists: 'هذا البريد مسجّل مسبقاً، جرّب تسجيل الدخول.', errBadLogin: 'البريد أو كلمة المرور غير صحيحة.',
  errWeak: 'كلمة المرور ضعيفة، استخدم 6 أحرف على الأقل.', errEmail: 'البريد الإلكتروني غير صالح.',
  errMany: 'محاولات كثيرة، انتظر قليلاً ثم أعد المحاولة.', errOp: 'تسجيل الدخول غير مفعّل بعد في إعدادات Firebase.',
  errGeneric: 'تعذر الاتصال، تحقق من الإنترنت وحاول مرة أخرى.',
  ph8: 'مثال: خطّط لي رحلة إلى إسطنبول، أو احجز طاولة لأربعة أشخاص غداً...',
  actCal: 'أضف إلى التقويم', actMail: 'افتح في البريد', actMap: 'ابحث في الخرائط', actFlight: 'ابحث عن الرحلات',
  actHotel: 'ابحث عن الفنادق', actCopy: 'انسخ النص', actLink: 'افتح الرابط', copied: 'تم النسخ',
  examples: 'جرّب أحد هذه الأمثلة:',
  rateAsk: 'ما رأيك في AQLira؟', later: 'لاحقاً',
  ex0a: 'هاتفي يفصل الشحن بسرعة، ما الحل؟',
  ex0b: 'أتأخر دائماً في الاستيقاظ صباحاً',
  ex0c: 'خلاف مع زميل في العمل، كيف أتصرف؟',
  ex1a: 'فكرتي متجر عطور إلكتروني',
  ex1b: 'أريد تطبيقاً لتعليم الأطفال',
  ex1c: 'مشروع مطعم وجبات صحية منزلي',
  ex2a: 'عندي مقهى صغير، أريد إعلاناً',
  ex2b: 'اكتب 5 منشورات إنستغرام لمتجر ملابس',
  ex2c: 'أفكار فيديوهات تيك توك لمنتجي',
  ex3a: 'أرفق صورة واسأل: ماذا تعني؟',
  ex3b: 'الصق نص عقد وأريد تلخيصه',
  ex3c: 'اشرح لي هذا الجدول',
  ex4a: 'أريد تعلّم الإنجليزية خلال 3 أشهر',
  ex4b: 'هدفي خسارة 5 كغ وعندي ساعة يومياً',
  ex4c: 'خطة دراسة لامتحان بعد أسبوعين',
  ex5a: 'صورة مصغّرة ليوتيوب عن وصفات القهوة',
  ex5b: 'شعار بسيط لمتجر ورد',
  ex5c: 'غلاف كتاب عن الفضاء',
  ex6a: 'فيلم كرتوني عن قطة تحب البحر',
  ex6b: 'مشهد مطاردة مضحك بين فأر وقط',
  ex6c: 'قصة طفل يصادق روبوتاً',
  ex7a: 'ذكّرني بموعد الطبيب الخميس 5 مساء',
  ex7b: 'الصق بريداً أريد تلخيصه والرد عليه',
  ex7c: 'رتّب لي جدولاً أسبوعياً',
  ex8a: 'مطعم إيطالي لأربعة أشخاص مساء الجمعة',
  ex8b: 'رحلة إلى إسطنبول لثلاثة أيام',
  ex8c: 'ساعدني في ملء نموذج طلب',
  imgPolli: 'تم توليد الصورة. مواصفات الصورة:',
  imgFail: 'تعذر توليد الصورة الآن (قد يتطلب ذلك تفعيل الفوترة لدى Google). هذا وصف جاهز تنسخه إلى تطبيق Gemini المجاني لتوليد الصورة:',
  phGeneral: 'اسأل AQLira أي شيء...',
  rate: 'قيّم التطبيق', rateHint: 'اضغط على النجوم لتقييم التطبيق', rateThanks: 'شكراً لتقييمك!', of5: 'من 5',
  newChat: '+ جديد', history: 'المحفوظات', typing: 'يكتب...',
  noChats: 'لا توجد مشاريع محفوظة بعد. ابدأ محادثة وستُحفظ تلقائياً.', del: 'حذف', back: 'رجوع',
  freeMonth: 'شهرك الأول مجاني بالكامل', daysLeft: 'متبقي {n} يوماً', freeEnded: 'انتهى الشهر المجاني',
  freeNote: 'لا توجد اشتراكات حالياً، وكل المزايا متاحة لك.',
  myAccount: 'حسابي', userName: 'مستخدم AQLira',
  privacy: 'محادثاتك ومشاريعك محفوظة على جهازك فقط.',
  langTitle: 'اللغة', langOther: 'لغة أخرى: اكتب اسمها', apply: 'تطبيق',
  translating: 'جارٍ ترجمة التطبيق...', langDone: 'تم تغيير اللغة', langFail: 'تعذرت الترجمة، حاول مرة أخرى.',
  errServer: 'تعذر الاتصال بالخادم. تحقق من الإنترنت وحاول مرة أخرى.',
  imgDefault: 'حلّل هذه الصورة.', imgTag: '(صورة)',
};

const UI_EN = {
  tagline: 'Your intelligence. Your possibilities.',
  t0: 'Solve my problem', t1: 'Turn my idea into a project', t2: 'Market for me', t3: 'Understand what I see', t4: 'Plan for me', t5: 'Design or edit an image', t7: 'Manage your life', t8: 'Get things done', t6: 'Cartoon film studio',
  ph0: 'Describe your problem here...', ph1: 'Write your idea here...', ph2: 'Tell me about your business or product...',
  ph3: 'Attach an image or paste text...', ph4: 'Write your goal and available time...',
  ph5: 'Describe the image or thumbnail, or attach an image to edit...', ph6: 'Write your film idea or cartoon scene...',
  generating: 'Designing...',
  ph7: 'Example: remind me of my doctor appointment Thursday at 5 pm, or paste an email to summarize and reply...',
  linkCalendar: 'Add to calendar', linkMail: 'Open in email', linkMaps: 'Open in Maps', linkFlights: 'Search flights', linkHotels: 'Search hotels', linkOpen: 'Open link',
  authSub: 'Sign in so your chats and projects are saved and available on any device.',
  email: 'Email', password: 'Password (at least 6 characters)',
  signIn: 'Sign in', signUp: 'Create account', toSignUp: "Don't have an account? Create one", toSignIn: 'Have an account? Sign in',
  forgot: 'Forgot your password?', resetSent: 'We sent a password reset link to your email.', needEmail: 'Enter your email first.',
  logout: 'Sign out', privacyCloud: 'Your chats and projects are saved in your account and available on any device.',
  errEmailExists: 'This email is already registered, try signing in.', errBadLogin: 'Incorrect email or password.',
  errWeak: 'Weak password, use at least 6 characters.', errEmail: 'Invalid email address.',
  errMany: 'Too many attempts, please wait a moment and try again.', errOp: 'Sign-in is not enabled yet in the Firebase settings.',
  errGeneric: 'Could not connect, check your internet and try again.',
  ph8: 'Example: plan a trip to Istanbul, or book a table for four tomorrow...',
  actCal: 'Add to calendar', actMail: 'Open in mail', actMap: 'Search on Maps', actFlight: 'Search flights',
  actHotel: 'Search hotels', actCopy: 'Copy text', actLink: 'Open link', copied: 'Copied',
  examples: 'Try one of these:',
  rateAsk: 'What do you think of AQLira?', later: 'Later',
  ex0a: 'My phone battery drains fast, what can I do?',
  ex0b: 'I always wake up late, help me',
  ex0c: 'Conflict with a coworker, how should I act?',
  ex1a: 'My idea is an online perfume shop',
  ex1b: 'I want an app that teaches kids',
  ex1c: 'A home healthy-meals restaurant project',
  ex2a: 'I have a small cafe, I need an ad',
  ex2b: 'Write 5 Instagram posts for a clothing store',
  ex2c: 'TikTok video ideas for my product',
  ex3a: 'Attach a photo and ask what it means',
  ex3b: 'Paste a contract text to summarize',
  ex3c: 'Explain this table to me',
  ex4a: 'I want to learn English in 3 months',
  ex4b: 'Goal: lose 5 kg, I have 1 hour daily',
  ex4c: 'Study plan for an exam in two weeks',
  ex5a: 'YouTube thumbnail about coffee recipes',
  ex5b: 'Simple logo for a flower shop',
  ex5c: 'Book cover about space',
  ex6a: 'Cartoon film about a cat who loves the sea',
  ex6b: 'Funny chase scene between a mouse and a cat',
  ex6c: 'A boy who befriends a robot',
  ex7a: 'Remind me of the doctor on Thursday at 5 pm',
  ex7b: 'Paste an email to summarize and reply to',
  ex7c: 'Arrange a weekly schedule for me',
  ex8a: 'Italian restaurant for four, Friday evening',
  ex8b: 'A 3-day trip to Istanbul',
  ex8c: 'Help me fill in an application form',
  imgPolli: 'Image generated. Image details:',
  imgFail: 'The image could not be generated right now (it may require billing on Google). Here is a ready prompt you can paste into the free Gemini app:',
  phGeneral: 'Ask AQLira anything...',
  rate: 'Rate the app', rateHint: 'Tap the stars to rate the app', rateThanks: 'Thanks for your rating!', of5: 'out of 5',
  newChat: '+ New', history: 'Saved', typing: 'Typing...',
  noChats: 'No saved projects yet. Start a chat and it will be saved automatically.', del: 'Delete', back: 'Back',
  freeMonth: 'Your first month is completely free', daysLeft: '{n} days left', freeEnded: 'The free month has ended',
  freeNote: 'There are no subscriptions at the moment, and every feature is available to you.',
  myAccount: 'My account', userName: 'AQLira user',
  privacy: 'Your chats and projects are saved on your device only.',
  langTitle: 'Language', langOther: 'Other language: type its name', apply: 'Apply',
  translating: 'Translating the app...', langDone: 'Language changed', langFail: 'Translation failed, please try again.',
  errServer: 'Could not reach the server. Check your internet and try again.',
  imgDefault: 'Analyze this image.', imgTag: '(image)',
};

const LANGS = [
  { code: 'ar', name: 'العربية', rtl: true },
  { code: 'en', name: 'English' },
  { code: 'fr', name: 'Français' },
  { code: 'es', name: 'Español' },
  { code: 'de', name: 'Deutsch' },
  { code: 'tr', name: 'Türkçe' },
  { code: 'fa', name: 'فارسی', rtl: true },
  { code: 'ur', name: 'اردو', rtl: true },
  { code: 'ru', name: 'Русский' },
  { code: 'zh', name: '中文' },
  { code: 'ja', name: '日本語' },
  { code: 'ko', name: '한국어' },
  { code: 'hi', name: 'हिन्दी' },
  { code: 'id', name: 'Bahasa Indonesia' },
  { code: 'pt', name: 'Português' },
  { code: 'it', name: 'Italiano' },
  { code: 'he', name: 'עברית', rtl: true },
];

// ---------- الأدوات الخمس ----------
const TOOLS = [
  {
    k: 't0', ph: 'ph0',
    prompt: 'أنت في وضع "حل مشكلتي". عندما يشرح المستخدم مشكلة: حلّل تفاصيلها، حدّد الأسباب المحتملة، قدّم عدة حلول، اشرح إيجابيات وسلبيات كل حل، ثم اقترح أفضل خطوات للبدء. إذا كانت المعلومات ناقصة فاسأل سؤالاً واحداً مهماً قبل الإجابة. أجب بنفس لغة المستخدم، وقدّم الجواب مفصّلاً وكاملاً وشاملاً.',
  },
  {
    k: 't1', ph: 'ph1',
    prompt: 'أنت في وضع "حوّل فكرتي إلى مشروع". عندما يذكر المستخدم فكرة: حلّلها، اقترح أسماء للمشروع، حدّد الجمهور المستهدف، ادرس المنافسين بشكل أولي، اقترح طرق تحقيق الدخل، أعدّ خطة عمل، ضع خطوات الإطلاق، واقترح استراتيجية تسويق. إذا لم تكن الفكرة واضحة فاسأل سؤالاً واحداً. أجب بنفس لغة المستخدم، وقدّم الجواب مفصّلاً وكاملاً وشاملاً.',
  },
  {
    k: 't2', ph: 'ph2',
    prompt: 'أنت في وضع "سوّق لي". ساعد أصحاب المشاريع بكتابة إعلانات تسويقية، أفكار حملات، منشورات Instagram وFacebook وTikTok، أسماء منتجات، أوصاف منتجات، أفكار فيديوهات قصيرة، طرق جذب العملاء، وخطط تسويقية. اجعل المحتوى مناسباً لجمهور المشروع. إذا لزم فاسأل سؤالاً واحداً عن المنتج أو الجمهور. أجب بنفس لغة المستخدم، وقدّم الجواب مفصّلاً وكاملاً وشاملاً.',
  },
  {
    k: 't3', ph: 'ph3',
    prompt: 'أنت في وضع "افهم ما أراه". المستخدم قد يرفق صورة أو يلصق نص مستند. إذا وُجدت صورة فصفها بوضوح، واقرأ أي نص فيها، واشرح ما تعنيه، وأجب عن أسئلته. وإذا كان نصاً فلخّصه واستخرج النقاط المهمة. لا تدّعِ رؤية شيء غير موجود، وإن كانت الصورة غير واضحة فقل ذلك. أجب بنفس لغة المستخدم، وقدّم الجواب مفصّلاً وكاملاً وشاملاً.',
  },
  {
    k: 't4', ph: 'ph4',
    prompt: 'أنت في وضع "خطّط بدلاً مني". حوّل هدف المستخدم إلى خطة منظمة: حدّد الهدف، قسّمه إلى مهام صغيرة، أنشئ جدولاً يومياً أو أسبوعياً، حدّد الأولويات، واقترح طرقاً لتحسين الالتزام. اسأل سؤالاً واحداً عن الوقت المتاح إن لم يُذكر. أجب بنفس لغة المستخدم، وقدّم الجواب مفصّلاً وكاملاً وشاملاً.',
  },
  {
    k: 't5', ph: 'ph5', mode: 'image',
    prompt: 'أنت مصمم صور. اكتب وصفاً دقيقاً للصورة أو الصورة المصغّرة المطلوبة. أجب بنفس لغة المستخدم، وقدّم الجواب مفصّلاً وكاملاً وشاملاً.',
  },
  {
    k: 't6', ph: 'ph6',
    prompt: 'أنت في وضع "استوديو الأفلام الكرتونية". عندما يذكر المستخدم فكرة فيلم أو مشهد: اكتب عنواناً وفكرة مختصرة، ثم وصف الشخصيات (شكلها وألوانها)، ثم مشاهد مرقمة. لكل مشهد: المكان، الحدث، الحوار أو التعليق الصوتي، زاوية الكاميرا، ثم سطر بعنوان "Video prompt:" بالإنجليزية يصف مقطعاً من 8 ثوانٍ جاهزاً للنسخ إلى مولّد فيديو، وسطر بعنوان "Image prompt:" بالإنجليزية للصورة المصغّرة أو لقطة الشخصية. في النهاية اقترح فكرة صورة مصغّرة جذابة. لا تدّعِ أنك أنتجت فيديو، فأنت تكتب السيناريو والأوصاف فقط. أجب بنفس لغة المستخدم، وقدّم الجواب مفصّلاً وكاملاً وشاملاً.',
  },
  {
    k: 't7', ph: 'ph7',
    prompt: 'أنت في وضع "إدارة حياتك". أنت مساعد شخصي ينظّم بريد المستخدم ومواعيده وتذكيراته. لا تملك وصولاً إلى حساباته، فاعمل على ما يلصقه أو يكتبه لك. (1) البريد: عندما يلصق رسالة بريد، لخّصها، واستخرج منها المطلوب والمهام والمواعيد، وحدّد الأولوية، واكتب مسودة رد مهذبة جاهزة، وعند الطلب أنشئ رابطاً جاهزاً بصيغة mailto:?subject=...&body=... بحيث تكون القيم مشفّرة بصيغة URL. (2) المواعيد والتذكيرات: نظّم جدوله وانتبه للتعارضات، وعند تحديد موعد أو تذكير أنشئ رابط Google Calendar جاهزاً بصيغة https://calendar.google.com/calendar/render?action=TEMPLATE&text=العنوان&dates=YYYYMMDDTHHMMSS/YYYYMMDDTHHMMSS&details=التفاصيل&location=المكان بحيث تكون القيم مشفّرة بصيغة URL، والوقت بتوقيت المستخدم المحلي. والتذكير يُنشأ كحدث في التقويم. استخدم تاريخ اليوم المعطى لك في تعليمات النظام لتحويل عبارات مثل غداً والخميس القادم إلى تواريخ صحيحة، واسأل عن الوقت إن لم يُذكر. (3) اعرض للمستخدم نتيجة واضحة ومنظمة: تفاصيل الموعد (العنوان واليوم والتاريخ والوقت)، ثم الرابط الجاهز، ثم نصيحة أو اقتراح مفيد واحد. لا تشرح طريقة حسابك الداخلية ولا كيفية ترميز الروابط. لا تدّعِ أنك أرسلت بريداً أو أضفت حدثاً بنفسك، بل قل إنك جهّزت الرابط وعلى المستخدم الضغط عليه. لا تطلب كلمات مرور أبداً. اكتب الروابط كاملة كنص عادي دون تنسيق Markdown. أجب بنفس لغة المستخدم، وقدّم الجواب مفصّلاً وكاملاً وشاملاً.',
  },
  {
    k: 't8', ph: 'ph8',
    prompt: 'أنت في وضع "إنجاز المهام". تساعد في حجز المطاعم والسفر وملء النماذج عبر الإنترنت، لكنك لا تستطيع تنفيذ الحجز ولا إرسال النماذج بنفسك. مهمتك تجهيز كل شيء ليُنجزه المستخدم بضغطة أو نسخة. (1) المطاعم والفنادق والرحلات: اسأل سؤالاً واحداً عن المدينة والتاريخ والعدد والميزانية إن نقصت، ثم قارن خيارات حقيقية مستعيناً بالبحث، واذكر مزايا كل خيار، وأعطِ روابط بحث جاهزة: خرائط Google بصيغة https://www.google.com/maps/search/?api=1&query=...، والرحلات بصيغة https://www.google.com/travel/flights?q=...، والفنادق بصيغة https://www.booking.com/searchresults.html?ss=... بحيث تكون القيم مشفّرة بصيغة URL، واكتب نص رسالة الحجز أو الاتصال جاهزاً. (2) النماذج: عندما يصف المستخدم نموذجاً أو يلصق حقوله، اكتب إجابة كل حقل جاهزة للنسخ بترتيبها، ونبّه على ما ينقص وعلى المستندات المطلوبة. (3) قدّم قائمة تحقق بالخطوات. لا تطلب كلمات مرور أو أرقام بطاقات أبداً، ولا تدّعِ أنك حجزت أو أرسلت شيئاً، واطلب من المستخدم التحقق من الأسعار والتفاصيل في الموقع الرسمي قبل الدفع. اكتب الروابط كاملة كنص عادي دون تنسيق Markdown. أجب بنفس لغة المستخدم، وقدّم الجواب مفصّلاً وكاملاً وشاملاً.',
  },
];
const ACTION_RULES = 'قواعد الأزرار: بعد جوابك المكتوب، يمكنك أن تضيف في آخر الرد أسطراً مستقلة تبدأ كل منها بعلامة @@ لإنشاء أزرار تفتح للمستخدم صفحات جاهزة، ولا تكتب أي شيء بعد هذه الأسطر. الصيغ بالضبط: @@EVENT|عنوان الموعد|YYYY-MM-DDTHH:MM|YYYY-MM-DDTHH:MM|ملاحظات ... @@MAIL|البريد المستلم أو فارغ|الموضوع|نص الرسالة (استبدل كل سطر جديد بالرمز \\n) ... @@MAP|عبارة بحث للخرائط ... @@FLIGHT|مدينة المغادرة|مدينة الوصول|YYYY-MM-DD|تاريخ العودة أو فارغ ... @@HOTEL|المدينة|YYYY-MM-DD|YYYY-MM-DD|عدد البالغين ... @@COPY|عنوان|النص الجاهز للنسخ (استبدل كل سطر جديد بالرمز \\n) ... @@LINK|وصف|رابط https أعطاه المستخدم نفسه فقط. استخدم فقط ما يلزم فعلاً، ولا تخترع عناوين أو أرقام هواتف أو أسعاراً أو توفراً. اسأل سؤالاً واحداً عن أهم معلومة ناقصة قبل إنشاء الأزرار. استخدم الوقت الحالي المذكور لتحويل كلمات مثل غداً والخميس إلى تواريخ صحيحة.';

const IMG_FALLBACK_PROMPT = 'تعذر توليد الصورة تلقائياً. اكتب للمستخدم: (1) أفضل وصف (Prompt) بالإنجليزية جاهزاً للنسخ إلى مولّد صور، بدون معاملات تقنية مثل --ar، (2) اقتراحات للتكوين والألوان والنص المناسب إن كانت صورة مصغّرة. اجعل الشرح بنفس لغة المستخدم.';

const POLLI_PROMPT = 'Convert the user request into an image-generation request. Reply with EXACTLY two lines and nothing else. Line 1: "PROMPT: " followed by ONE concise English prompt (max 60 words) describing the subject, style, lighting and composition; if it is a thumbnail make it eye-catching, do not ask for text inside the image, and add no technical parameters. Line 2: "SPECS: " followed by a short description (one or two sentences) of the image, written in the SAME language as the user request.';

const ORDER = [1, 0, 2, 3, 4, 7, 8, 5, 6];

// ---------- اتجاه الواجهة ----------
let RTL = true;
const rowDir = () => (RTL ? 'row-reverse' : 'row');
const gapKey = () => (RTL ? 'marginRight' : 'marginLeft');
const beginSide = () => (RTL ? 'flex-end' : 'flex-start');
const align = () => (RTL ? 'right' : 'left');

function Logo({ size = 80 }) {
  return (
    <Image
      source={{ uri: LOGO_URI }}
      style={{ width: size, height: size, borderRadius: size * 0.22 }}
    />
  );
}

function PersonIcon({ color }) {
  const b = { borderWidth: 2, borderColor: color };
  return (
    <View style={{ alignItems: 'center' }}>
      <View style={{ ...b, width: 10, height: 10, borderRadius: 5 }} />
      <View style={{ ...b, width: 20, height: 9, borderTopLeftRadius: 10, borderTopRightRadius: 10, marginTop: 2 }} />
    </View>
  );
}

function linkLabel(url, t) {
  if (/^mailto:/i.test(url)) return t('linkMail');
  if (/calendar\.google\.com/i.test(url)) return t('linkCalendar');
  if (/google\.[a-z.]+\/maps/i.test(url)) return t('linkMaps');
  if (/google\.[a-z.]+\/travel\/flights/i.test(url)) return t('linkFlights');
  if (/booking\.com|google\.[a-z.]+\/travel\/hotels/i.test(url)) return t('linkHotels');
  const m = url.match(/^https?:\/\/([^\/]+)/i);
  return m ? m[1].replace(/^www\./, '') : t('linkOpen');
}

function RichText({ text, style, t }) {
  const parts = String(text).split(/(https?:\/\/[^\s<>"']+|mailto:[^\s<>"']+)/g);
  return (
    <Text style={style} selectable>
      {parts.map((p, i) => {
        if (/^(https?:|mailto:)/i.test(p)) {
          const url = p.replace(/[).,;]+$/, '');
          const tail = p.slice(url.length);
          return (
            <Text key={i}>
              <Text
                style={{ color: C.greenText, textDecorationLine: 'underline', fontWeight: '700' }}
                onPress={() => { try { Linking.openURL(url); } catch (e) {} }}
              >
                {linkLabel(url, t)}
              </Text>
              {tail}
            </Text>
          );
        }
        return p;
      })}
    </Text>
  );
}

function clean(x) {
  return String(x)
    .replace(/\*\*/g, '')
    .replace(/^#{1,6}\s*/gm, '')
    .replace(/^\s*[>]\s*/gm, '')
    .replace(/^\s*\*\s+/gm, '• ')
    .replace(/^-{3,}$/gm, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

// ---------- أزرار الإجراءات (تقويم، بريد، خرائط، رحلات، فنادق، نسخ) ----------
const enc = encodeURIComponent;
const isDate = s => /^\d{4}-\d{2}-\d{2}$/.test(s || '');
const isDT = s => /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(s || '');
const calFmt = iso => iso.slice(0, 16).replace(/[-:]/g, '') + '00';
const plusHour = iso => {
  const y = +iso.slice(0, 4), mo = +iso.slice(5, 7), d = +iso.slice(8, 10), h = +iso.slice(11, 13), mi = +iso.slice(14, 16);
  const x = new Date(y, mo - 1, d, h + 1, mi);
  const p = n => String(n).padStart(2, '0');
  return x.getFullYear() + '-' + p(x.getMonth() + 1) + '-' + p(x.getDate()) + 'T' + p(x.getHours()) + ':' + p(x.getMinutes());
};
const short = s => (s.length > 26 ? s.slice(0, 26) + '…' : s);

function buildAction(type, p) {
  if (type === 'EVENT' && p[1] && isDT(p[2])) {
    const end = isDT(p[3]) ? p[3] : plusHour(p[2]);
    return { k: 'actCal', detail: short(p[1]),
      url: 'https://calendar.google.com/calendar/render?action=TEMPLATE&text=' + enc(p[1]) +
        '&dates=' + calFmt(p[2]) + '/' + calFmt(end) + '&details=' + enc(p.slice(4).join(' | ')) };
  }
  if (type === 'MAIL' && (p[2] || p[3])) {
    const body = p.slice(3).join('|').replace(/\\n/g, '\n');
    return { k: 'actMail', detail: short(p[2] || ''),
      url: 'mailto:' + (p[1] || '') + '?subject=' + enc(p[2] || '') + '&body=' + enc(body) };
  }
  if (type === 'MAP' && p[1]) {
    return { k: 'actMap', detail: short(p[1]), url: 'https://www.google.com/maps/search/?api=1&query=' + enc(p[1]) };
  }
  if (type === 'FLIGHT' && p[1] && p[2]) {
    const q = 'Flights from ' + p[1] + ' to ' + p[2] + (isDate(p[3]) ? ' on ' + p[3] : '') + (isDate(p[4]) ? ' returning ' + p[4] : '');
    return { k: 'actFlight', detail: short(p[1] + ' → ' + p[2]), url: 'https://www.google.com/travel/flights?q=' + enc(q) };
  }
  if (type === 'HOTEL' && p[1]) {
    let u = 'https://www.booking.com/searchresults.html?ss=' + enc(p[1]);
    if (isDate(p[2]) && isDate(p[3])) u += '&checkin=' + p[2] + '&checkout=' + p[3];
    if (/^\d+$/.test(p[4] || '')) u += '&group_adults=' + p[4];
    return { k: 'actHotel', detail: short(p[1]), url: u };
  }
  if (type === 'COPY' && p[2]) {
    return { k: 'actCopy', detail: short(p[1] || ''), copy: p.slice(2).join('|').replace(/\\n/g, '\n') };
  }
  if (type === 'LINK' && /^https:\/\//i.test(p[2] || '')) {
    return { k: 'actLink', detail: short(p[1] || ''), url: p[2] };
  }
  return null;
}

function parseActions(text) {
  const keep = [];
  const actions = [];
  const canCopy = typeof navigator !== 'undefined' && navigator.clipboard && Platform.OS === 'web';
  String(text).split('\n').forEach(line => {
    const s = line.trim();
    if (s.startsWith('@@')) {
      const p = s.slice(2).split('|').map(x => x.trim());
      const a = buildAction((p[0] || '').toUpperCase(), p);
      if (a && a.copy && !canCopy) keep.push('\n' + (a.detail ? a.detail + ':\n' : '') + a.copy);
      else if (a && actions.length < 6) actions.push(a);
    } else {
      keep.push(line);
    }
  });
  return { text: keep.join('\n').replace(/\n{3,}/g, '\n\n').trim(), actions };
}

// ---------- الشاشة الرئيسية والمحادثة ----------
function Main({ t, rtl, daysLeft, setChats, openChat, openProfile, openHistory }) {
  const [tool, setTool] = useState(null);
  const [msgs, setMsgs] = useState([]);
  const [chatId, setChatId] = useState(null);
  const [txt, setTxt] = useState('');
  const [loading, setLoading] = useState(false);
  const [pending, setPending] = useState(null);
  const [rate, setRate] = useState(0);
  const [rateOpen, setRateOpen] = useState(false);
  const repliesRef = useRef(0);
  const ratedRef = useRef(false);
  const [showRate, setShowRate] = useState(false);
  const scroller = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    Store.get('aq_rated').then(v => { if (v) ratedRef.current = true; }).catch(() => {});
  }, []);
  const [toast, setToast] = useState('');
  const cfg = tool === null ? null : TOOLS[tool];
  const started = msgs.length > 0;

  useEffect(() => {
    if (openChat) {
      setMsgs(openChat.msgs);
      setTool(openChat.tool === undefined ? null : openChat.tool);
      setChatId(openChat.id);
      setTxt('');
      setPending(null);
      setShowRate(false);
    }
  }, [openChat]);

  useEffect(() => {
    if (!msgs.length || !chatId || loading) return;
    const first = msgs.find(m => m.me);
    const title = first ? first.text : 'AQLira';
    const saved = msgs.map(m => ({ id: m.id, me: m.me, text: m.text, hadImg: !!(m.img || m.hadImg), actions: m.actions }));
    setChats(prev => [
      { id: chatId, title: title.slice(0, 40), tool, updated: Date.now(), msgs: saved },
      ...prev.filter(c => c.id !== chatId),
    ].slice(0, 50));
  }, [msgs, loading]);

  useEffect(() => {
    if (tool !== null && inputRef.current && inputRef.current.focus) {
      setTimeout(() => { try { inputRef.current.focus(); } catch (e) {} }, 60);
    }
  }, [tool]);

  const runAction = async a => {
    if (a.copy) {
      try {
        await navigator.clipboard.writeText(a.copy);
        setToast(t('copied'));
        setTimeout(() => setToast(''), 1800);
      } catch (e) {}
      return;
    }
    if (a.url) { try { await Linking.openURL(a.url); } catch (e) {} }
  };

  const newChat = () => {
    setMsgs([]); setTool(null); setChatId(null); setTxt(''); setPending(null); setShowRate(false);
  };

  const pick = () => {
    if (Platform.OS !== 'web' || typeof document === 'undefined') return;
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.accept = 'image/*';
    inp.onchange = () => {
      const f = inp.files && inp.files[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = () => {
        const img = new window.Image();
        img.onload = () => {
          const sc = Math.min(1, 1024 / Math.max(img.width, img.height));
          const cv = document.createElement('canvas');
          cv.width = Math.round(img.width * sc);
          cv.height = Math.round(img.height * sc);
          cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
          const url = cv.toDataURL('image/jpeg', 0.7);
          setPending({ uri: url, mime: 'image/jpeg', data: url.split(',')[1] });
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(f);
    };
    inp.click();
  };

  const send = async () => {
    const q = txt.trim() || (pending ? t('imgDefault') : '');
    if (!q || loading) return;
    let cid = chatId;
    if (!cid) { cid = String(Date.now()); setChatId(cid); }
    const id = Date.now();
    const next = [...msgs, {
      id, me: true, text: q,
      img: pending ? pending.uri : undefined,
      imgData: pending ? { mime: pending.mime, data: pending.data } : undefined,
    }];
    setMsgs(next);
    setTxt('');
    setPending(null);
    setLoading(true);
    let reply;
    let outImg;
    let okReply = false;
    let outSize;
    let outActions;
    const post = body => fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then(r => r.json());
    const buildConvo = () => {
      const recent = next.slice(-11);
      let lastImg = -1;
      recent.forEach((m, i) => { if (m.imgData) lastImg = i; });
      return recent.map((m, i) => ({
        role: m.me ? 'user' : 'model',
        text: m.text || '(image)',
        image: i === lastImg ? m.imgData : undefined,
      }));
    };
    try {
      if (cfg && cfg.mode === 'image') {
        const src = next[next.length - 1].imgData;
        const d = await post({ action: 'image', prompt: q, image: src });
        if (d.image) {
          okReply = true;
          outImg = 'data:' + d.image.mime + ';base64,' + d.image.data;
          reply = clean(d.text || '');
        } else if (!src) {
          const f = await post({
            messages: [{ role: 'user', text: POLLI_PROMPT }, { role: 'model', text: 'OK' }, ...buildConvo()],
          });
          const raw = clean(f.reply || '');
          const pm = raw.match(/PROMPT:\s*([\s\S]*?)(?:\n\s*SPECS:|$)/i);
          const sm = raw.match(/SPECS:\s*([\s\S]*)$/i);
          const ep = (pm ? pm[1] : raw).replace(/--\w+\s*\S*/g, '').slice(0, 400).trim();
          const specs = sm && sm[1].trim() ? sm[1].trim() : ep;
          if (ep && !f.error) {
            okReply = true;
            const wide = /مصغر|thumbnail|youtube|يوتيوب|banner|غلاف|cover/i.test(q);
            const w = wide ? 1024 : 768;
            const h = wide ? 576 : 768;
            outImg = 'https://image.pollinations.ai/prompt/' + encodeURIComponent(ep) +
              '?width=' + w + '&height=' + h + '&nologo=true&seed=' + Math.floor(Math.random() * 100000);
            outSize = wide ? 'wide' : 'square';
            reply = t('imgPolli') + '\n' + specs;
          } else {
            reply = t('errServer');
          }
        } else {
          const f = await post({
            messages: [{ role: 'user', text: IMG_FALLBACK_PROMPT }, { role: 'model', text: 'OK' }, ...buildConvo()],
          });
          reply = t('imgFail') + (d.detail ? '\n(' + d.detail + ')' : '') + '\n\n' + clean(f.reply || f.error || t('errServer'));
        }
      } else {
        const convo = buildConvo();
        const history = cfg
          ? [{ role: 'user', text: cfg.prompt + ' (الوقت الحالي للمستخدم: ' + new Date().toString() + ')' }, { role: 'model', text: 'OK' }, ...convo]
          : convo;
        let tz = '';
        try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) {}
        const d = await post({ messages: history, tz });
        okReply = !!d.reply;
        const pa = parseActions(clean(d.reply || d.error || t('errServer')));
        reply = pa.text;
        outActions = pa.actions;
      }
    } catch (e) {
      reply = t('errServer');
    }
    setMsgs(m => [...m, { id: id + 1, me: false, text: reply, img: outImg, size: outSize, actions: outActions }]);
    setLoading(false);
    if (okReply) {
      repliesRef.current += 1;
      if (!ratedRef.current && (repliesRef.current === 1 || repliesRef.current === 8)) {
        setTimeout(() => setRateOpen(true), 800);
      }
    }
  };

  const freeLine = t('freeMonth') + ' · ' + (daysLeft > 0 ? t('daysLeft').replace('{n}', String(daysLeft)) : t('freeEnded'));

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={st.top}>
        <TouchableOpacity style={st.topBtn} onPress={openProfile}>
          <PersonIcon color={C.muted} />
        </TouchableOpacity>
        <View style={st.topRow}>
          <TouchableOpacity onPress={openHistory}><Text style={st.topLink}>{t('history')}</Text></TouchableOpacity>
          {started ? (
            <TouchableOpacity onPress={newChat}><Text style={st.topLink}>{t('newChat')}</Text></TouchableOpacity>
          ) : null}
        </View>
      </View>

      <View style={{ flex: 1 }}>
      {started ? (
        <Image
          source={{ uri: LOGO_URI }}
          pointerEvents="none"
          style={{ position: 'absolute', top: '22%', left: '50%', marginLeft: -140, width: 280, height: 280, borderRadius: 62, opacity: 0.07 }}
        />
      ) : null}
      <ScrollView
        style={{ flex: 1 }}
        ref={scroller}
        contentContainerStyle={{ padding: 20, paddingBottom: 10 }}
        onContentSizeChange={() => { if (started && scroller.current) scroller.current.scrollToEnd({ animated: true }); }}
      >
        {!started ? (
          <View>
            <View style={{ alignItems: 'center', marginBottom: 20 }}>
              <Logo size={132} />
              <Text style={st.brand}>AQLira</Text>
              <Text style={st.tagline}>{t('tagline')}</Text>
              <View style={st.free}><Text style={st.freeTxt}>{freeLine}</Text></View>
            </View>
            {cfg ? (
              <View style={{ marginBottom: 6 }}>
                <Text style={[st.cardDesc, { marginBottom: 2 }]}>{t('examples')}</Text>
                {['a', 'b', 'c'].map(x => (
                  <TouchableOpacity key={x} style={st.example} onPress={() => { setTxt(t('ex' + tool + x)); try { inputRef.current && inputRef.current.focus(); } catch (e) {} }}>
                    <Text style={st.exampleTxt}>{t('ex' + tool + x)}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            ) : null}
            {ORDER.filter(i => i !== tool).map((i, k) => (
              <TouchableOpacity key={i} style={st.rect} onPress={() => setTool(i)}>
                <View style={[st.dot, { backgroundColor: k % 2 === 0 ? C.purple : C.green }]} />
                <Text style={st.rectTxt}>{t(TOOLS[i].k)}</Text>
                <Text style={{ color: C.muted, fontSize: 22 }}>{rtl ? '‹' : '›'}</Text>
              </TouchableOpacity>
            ))}
          </View>
        ) : (
          <View>
            {msgs.map(m => (
              <View key={m.id} style={[st.bubble, m.me ? st.me : st.bot]}>
                {m.img ? <Image source={{ uri: m.img }} style={[st.chatImg, m.size === 'wide' && st.chatWide, m.size === 'square' && st.chatSquare]} /> : null}
                {!m.img && m.hadImg ? (
                  <Text style={[m.me ? st.meTxt : st.botTxt, { opacity: 0.7, marginBottom: 4 }]}>{t('imgTag')}</Text>
                ) : null}
                {m.text ? (m.me ? <Text style={st.meTxt}>{m.text}</Text> : <RichText t={t} text={m.text} style={st.botTxt} />) : null}
                {!m.me && m.text && Platform.OS === 'web' ? (
                  <TouchableOpacity onPress={() => runAction({ copy: m.text })} style={{ alignSelf: beginSide(), marginTop: 4 }}>
                    <Text style={{ color: C.muted, fontSize: 12 }}>{t('actCopy')}</Text>
                  </TouchableOpacity>
                ) : null}
                {m.actions && m.actions.length ? (
                  <View style={{ marginTop: 6 }}>
                    {m.actions.map((a, i) => (
                      <TouchableOpacity key={i} style={st.action} onPress={() => runAction(a)}>
                        <Text style={st.actionTxt}>{t(a.k) + (a.detail ? ' · ' + a.detail : '')}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                ) : null}
              </View>
            ))}
            {loading ? (
              <View style={[st.bubble, st.bot]}><Text style={st.botTxt}>{cfg && cfg.mode === 'image' ? t('generating') : t('typing')}</Text></View>
            ) : null}
          </View>
        )}
      </ScrollView>
      </View>

      <View style={st.dock}>
        {toast ? <Text style={{ color: C.greenText, textAlign: 'center', marginBottom: 6, fontSize: 13 }}>{toast}</Text> : null}
        {cfg || pending ? (
          <View style={[st.row, { marginBottom: 8, flexWrap: 'wrap' }]}>
            {cfg ? (
              <TouchableOpacity style={st.chip} onPress={() => setTool(null)}>
                <Text style={st.chipTxt}>{t(cfg.k)}  ×</Text>
              </TouchableOpacity>
            ) : null}
            {pending ? (
              <View style={[st.row, { [gapKey()]: 8 }]}>
                <Image source={{ uri: pending.uri }} style={st.thumb} />
                <TouchableOpacity onPress={() => setPending(null)} style={st.thumbX}>
                  <Text style={{ color: C.text, fontWeight: '700' }}>×</Text>
                </TouchableOpacity>
              </View>
            ) : null}
          </View>
        ) : null}
        <View style={st.row}>
          <TouchableOpacity style={st.sendBtn} onPress={send}>
            <Text style={st.sendTxt}>{rtl ? '←' : '→'}</Text>
          </TouchableOpacity>
          <TextInput
            ref={inputRef}
            style={[st.input, { height: undefined, minHeight: 48, maxHeight: 120, paddingTop: 13, paddingBottom: 13, [gapKey()]: 8 }]}
            value={txt}
            onChangeText={setTxt}
            multiline
            placeholder={cfg ? t(cfg.ph) : t('phGeneral')}
            placeholderTextColor={C.muted}
            textAlign={rtl ? 'right' : 'left'}
            onSubmitEditing={send}
            onKeyPress={e => {
              const ne = e && e.nativeEvent;
              if (Platform.OS === 'web' && ne && ne.key === 'Enter' && !ne.shiftKey) {
                if (e.preventDefault) e.preventDefault();
                send();
              }
            }}
          />
          {Platform.OS === 'web' ? (
            <TouchableOpacity style={[st.attachBtn, { [gapKey()]: 8 }]} onPress={pick}>
              <Text style={{ color: C.greenText, fontSize: 24, marginTop: -2 }}>+</Text>
            </TouchableOpacity>
          ) : null}
        </View>
      </View>
      <Modal transparent visible={rateOpen} animationType="fade" onRequestClose={() => setRateOpen(false)}>
        <View style={st.modalBack}>
          <View style={st.modalCard}>
            <Text style={st.modalTitle}>{t('rateAsk')}</Text>
            <View style={{ flexDirection: 'row', marginVertical: 14 }}>
              {[1, 2, 3, 4, 5].map(v => (
                <TouchableOpacity
                  key={v}
                  onPress={() => {
                    setRate(v);
                    ratedRef.current = true;
                    Store.set('aq_rated', String(v));
                    setTimeout(() => setRateOpen(false), 1300);
                  }}
                >
                  <Text style={{ fontSize: 40, color: v <= rate ? '#F5A800' : '#C3CAD6', marginHorizontal: 4 }}>★</Text>
                </TouchableOpacity>
              ))}
            </View>
            <Text style={[st.cardDesc, { textAlign: 'center' }]}>
              {rate > 0 ? t('rateThanks') + ' ' + rate + ' ' + t('of5') : t('rateHint')}
            </Text>
            {rate === 0 ? (
              <TouchableOpacity onPress={() => setRateOpen(false)} style={{ marginTop: 14 }}>
                <Text style={{ color: C.muted, fontSize: 14 }}>{t('later')}</Text>
              </TouchableOpacity>
            ) : null}
          </View>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}

// ---------- المحفوظات ----------
function History({ t, chats, go, onOpen, onDelete }) {
  return (
    <ScrollView contentContainerStyle={st.pad}>
      <TouchableOpacity onPress={() => go('main')} style={{ alignSelf: beginSide(), marginBottom: 8 }}>
        <Text style={{ color: C.muted, fontSize: 15 }}>{RTL ? t('back') + ' ›' : '‹ ' + t('back')}</Text>
      </TouchableOpacity>
      <Text style={st.h1}>{t('history')}</Text>
      {chats.length === 0 ? (
        <Text style={[st.muted, { marginTop: 16, textAlign: align() }]}>{t('noChats')}</Text>
      ) : null}
      {chats.map(c => (
        <View key={c.id} style={[st.card, { marginTop: 12 }]}>
          <TouchableOpacity onPress={() => onOpen(c)}>
            <Text style={st.cardTitle}>{c.title}</Text>
            <Text style={st.cardDesc}>
              {(c.tool !== null && c.tool !== undefined ? t(TOOLS[c.tool].k) + ' · ' : '') + new Date(c.updated).toLocaleDateString()}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => onDelete(c.id)} style={{ alignSelf: beginSide(), marginTop: 8 }}>
            <Text style={{ color: '#D6334A', fontSize: 13 }}>{t('del')}</Text>
          </TouchableOpacity>
        </View>
      ))}
    </ScrollView>
  );
}

// ---------- الحساب واللغة ----------
function Profile({ t, go, daysLeft, lang, applyLang, busy, langMsg, session, onLogout }) {
  const [custom, setCustom] = useState('');
  return (
    <ScrollView contentContainerStyle={st.pad}>
      <TouchableOpacity onPress={() => go('main')} style={{ alignSelf: beginSide(), marginBottom: 8 }}>
        <Text style={{ color: C.muted, fontSize: 15 }}>{RTL ? t('back') + ' ›' : '‹ ' + t('back')}</Text>
      </TouchableOpacity>
      <View style={st.row}>
        <View style={st.avatar}><Text style={{ fontSize: 24, fontWeight: '700', color: C.ink }}>A</Text></View>
        <View style={{ [gapKey()]: 12 }}>
          <Text style={st.h2}>{session ? session.email : t('userName')}</Text>
          <Text style={st.cardDesc}>{t('myAccount')}</Text>
        </View>
      </View>

      <View style={[st.card, { marginTop: 16, borderColor: C.green }]}>
        <Text style={st.cardTitle}>{t('freeMonth')}</Text>
        <Text style={[st.cardDesc, { marginTop: 4, fontSize: 13 }]}>
          {daysLeft > 0 ? t('daysLeft').replace('{n}', String(daysLeft)) : t('freeEnded')}
        </Text>
        <Text style={[st.cardDesc, { marginTop: 6, fontSize: 13 }]}>{t('freeNote')}</Text>
      </View>

      <Text style={[st.cardDesc, { marginTop: 14, fontSize: 13 }]}>{session ? t('privacyCloud') : t('privacy')}</Text>
      {session ? (
        <TouchableOpacity onPress={onLogout} style={{ alignSelf: beginSide(), marginTop: 12 }}>
          <Text style={{ color: '#D6334A', fontSize: 14, fontWeight: '600' }}>{t('logout')}</Text>
        </TouchableOpacity>
      ) : null}

      <Text style={[st.h2, { marginTop: 22 }]}>{t('langTitle')}</Text>
      <View style={{ flexDirection: rowDir(), flexWrap: 'wrap', marginTop: 10 }}>
        {LANGS.map(L => (
          <TouchableOpacity
            key={L.code}
            disabled={busy}
            onPress={() => applyLang(L)}
            style={[st.langChip, lang.code === L.code && { borderColor: C.green, backgroundColor: '#E6FBF1' }]}
          >
            <Text style={{ color: lang.code === L.code ? C.greenText : C.text, fontSize: 14 }}>{L.name}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={[st.cardDesc, { marginTop: 16, fontSize: 13 }]}>{t('langOther')}</Text>
      <View style={[st.row, { marginTop: 8 }]}>
        <TouchableOpacity
          disabled={busy || !custom.trim()}
          onPress={() => applyLang({ code: 'x_' + custom.trim().toLowerCase(), name: custom.trim() })}
          style={[st.sendBtn, { width: 'auto', paddingHorizontal: 18, borderRadius: 24, height: 48 }]}
        >
          <Text style={{ color: C.ink, fontWeight: '700' }}>{t('apply')}</Text>
        </TouchableOpacity>
        <TextInput
          style={[st.input, { [gapKey()]: 8 }]}
          value={custom}
          onChangeText={setCustom}
          placeholder="Swahili, Thai, ..."
          placeholderTextColor={C.muted}
          textAlign={RTL ? 'right' : 'left'}
        />
      </View>
      {langMsg ? <Text style={[st.cardDesc, { marginTop: 10, color: C.greenText }]}>{langMsg}</Text> : null}
    </ScrollView>
  );
}

// ---------- شاشة تسجيل الدخول ----------
function AuthScreen({ t, onAuth, applyLang }) {
  const [mode, setMode] = useState('in');
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [err, setErr] = useState('');
  const [info, setInfo] = useState('');
  const [busyA, setBusyA] = useState(false);

  const submit = async () => {
    if (busyA) return;
    setErr(''); setInfo(''); setBusyA(true);
    try {
      const d = await fbAuth(mode === 'up' ? 'signUp' : 'signInWithPassword', {
        email: email.trim(), password: pw, returnSecureToken: true,
      });
      let createdAt = Date.now();
      try {
        const lk = await fbAuth('lookup', { idToken: d.idToken });
        const c = Number(lk.users && lk.users[0] && lk.users[0].createdAt);
        if (c) createdAt = c;
      } catch (e) {}
      await onAuth({
        uid: d.localId, email: d.email, idToken: d.idToken, refreshToken: d.refreshToken,
        expiresAt: Date.now() + (Number(d.expiresIn) - 60) * 1000, createdAt,
      });
    } catch (e) {
      setErr(t(errKey(e.message)));
    }
    setBusyA(false);
  };

  const forgot = async () => {
    setErr(''); setInfo('');
    if (!email.trim()) { setErr(t('needEmail')); return; }
    try {
      await fbAuth('sendOobCode', { requestType: 'PASSWORD_RESET', email: email.trim() });
      setInfo(t('resetSent'));
    } catch (e) {
      setErr(t(errKey(e.message)));
    }
  };

  return (
    <ScrollView contentContainerStyle={[st.pad, { paddingTop: 24 }]} keyboardShouldPersistTaps="handled">
      <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
        {[LANGS[0], LANGS[1]].map(L => (
          <TouchableOpacity key={L.code} onPress={() => applyLang(L)} style={st.langChip}>
            <Text style={{ color: C.text, fontSize: 14 }}>{L.name}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <View style={{ alignItems: 'center', marginVertical: 18 }}>
        <Logo size={110} />
        <Text style={st.brand}>AQLira</Text>
        <Text style={[st.tagline, { paddingHorizontal: 12 }]}>{t('authSub')}</Text>
        <View style={st.free}><Text style={st.freeTxt}>{t('freeMonth')}</Text></View>
      </View>
      <TextInput
        style={[st.input, { flex: 0, alignSelf: 'stretch', marginBottom: 10 }]}
        value={email}
        onChangeText={setEmail}
        placeholder={t('email')}
        placeholderTextColor={C.muted}
        autoCapitalize="none"
        autoCorrect={false}
        keyboardType="email-address"
        textAlign={RTL ? 'right' : 'left'}
      />
      <TextInput
        style={[st.input, { flex: 0, alignSelf: 'stretch' }]}
        value={pw}
        onChangeText={setPw}
        placeholder={t('password')}
        placeholderTextColor={C.muted}
        secureTextEntry
        autoCapitalize="none"
        textAlign={RTL ? 'right' : 'left'}
        onSubmitEditing={submit}
      />
      {err ? <Text style={{ color: '#D6334A', marginTop: 10, textAlign: align() }}>{err}</Text> : null}
      {info ? <Text style={{ color: C.greenText, marginTop: 10, textAlign: align() }}>{info}</Text> : null}
      <TouchableOpacity style={st.authBtn} onPress={submit} disabled={busyA}>
        <Text style={st.authBtnTxt}>{busyA ? '...' : (mode === 'up' ? t('signUp') : t('signIn'))}</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => { setMode(mode === 'up' ? 'in' : 'up'); setErr(''); setInfo(''); }} style={{ marginTop: 16 }}>
        <Text style={{ color: C.greenText, textAlign: 'center', fontSize: 15 }}>
          {mode === 'up' ? t('toSignIn') : t('toSignUp')}
        </Text>
      </TouchableOpacity>
      {mode === 'in' ? (
        <TouchableOpacity onPress={forgot} style={{ marginTop: 12 }}>
          <Text style={{ color: C.muted, textAlign: 'center', fontSize: 14 }}>{t('forgot')}</Text>
        </TouchableOpacity>
      ) : null}
    </ScrollView>
  );
}

// ---------- التطبيق ----------
export default function App() {
  const [screen, setScreen] = useState('main');
  const [chats, setChats] = useState([]);
  const [openChat, setOpenChat] = useState(null);
  const [lang, setLang] = useState({ code: 'ar', name: 'العربية' });
  const [dict, setDict] = useState(UI_AR);
  const [rtl, setRtl] = useState(true);
  const [busy, setBusy] = useState(false);
  const [langMsg, setLangMsg] = useState('');
  const [start, setStart] = useState(Date.now());
  const [ready, setReady] = useState(false);
  const [session, setSession] = useState(null);
  const [authReady, setAuthReady] = useState(!AUTH_ON);
  const [loaded, setLoaded] = useState(false);
  const sessRef = useRef(null);
  const saveTimer = useRef(null);
  const uid = session ? session.uid : 'guest';

  RTL = rtl;
  st = STYLES[rtl ? 'r' : 'l'] || (STYLES[rtl ? 'r' : 'l'] = makeStyles(rtl));
  const t = k => (dict && dict[k]) || UI_AR[k] || k;

  const applyLang = async (L, silent) => {
    const store = async () => { try { await Store.set('zy_lang', JSON.stringify(L)); } catch (e) {} };
    if (L.code === 'ar') { setDict(UI_AR); setRtl(true); setLang(L); setLangMsg(''); await store(); return; }
    if (L.code === 'en') { setDict(UI_EN); setRtl(false); setLang(L); setLangMsg(''); await store(); return; }
    setBusy(true);
    setLangMsg(t('translating'));
    try {
      const key = 'aq_dict_' + L.code;
      let pack = null;
      const raw = await Store.get(key);
      if (raw) pack = JSON.parse(raw);
      if (!pack) {
        const r = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'translate', lang: L.name, strings: UI_EN }),
        });
        const d = await r.json();
        if (!d.strings) throw new Error('no strings');
        pack = { rtl: !!d.rtl, strings: d.strings };
        await Store.set(key, JSON.stringify(pack));
      }
      const nd = { ...UI_EN, ...pack.strings };
      setDict(nd);
      setRtl(!!(L.rtl || pack.rtl));
      setLang(L);
      setLangMsg(silent ? '' : (nd.langDone || ''));
      await store();
    } catch (e) {
      setLangMsg(t('langFail'));
    }
    setBusy(false);
  };

  const persistSession = async s => {
    try {
      await Store.set('zy_session', s ? JSON.stringify({ uid: s.uid, email: s.email, refreshToken: s.refreshToken, createdAt: s.createdAt }) : '');
    } catch (e) {}
  };

  const freshToken = async () => {
    let s = sessRef.current;
    if (!s) throw new Error('no session');
    if (Date.now() > s.expiresAt) {
      const r = await fbRefresh(s.refreshToken);
      s = { ...s, ...r };
      sessRef.current = s;
      setSession(s);
      await persistSession(s);
    }
    return s;
  };

  const onAuth = async s => {
    sessRef.current = s;
    setSession(s);
    await persistSession(s);
  };

  const logout = async () => {
    await persistSession(null);
    sessRef.current = null;
    setLoaded(false);
    setChats([]);
    setSession(null);
    setScreen('main');
  };

  useEffect(() => {
    (async () => {
      try {
        let s0 = await Store.get('zy_start');
        if (!s0) { s0 = String(Date.now()); await Store.set('zy_start', s0); }
        setStart(Number(s0));
        const lraw = await Store.get('zy_lang');
        if (lraw) await applyLang(JSON.parse(lraw), true);
        if (AUTH_ON) {
          const sraw = await Store.get('zy_session');
          if (sraw) {
            const sv = JSON.parse(sraw);
            try {
              const r = await fbRefresh(sv.refreshToken);
              const s = { uid: sv.uid, email: sv.email, createdAt: sv.createdAt, ...r };
              sessRef.current = s;
              setSession(s);
            } catch (e) {}
          }
          setAuthReady(true);
        }
      } catch (e) { setAuthReady(true); }
      setReady(true);
    })();
  }, []);

  // تحميل المحادثات (محلياً، ومن حساب المستخدم إن كان مسجلاً) ودمجها
  useEffect(() => {
    if (!ready || !authReady) return;
    let cancelled = false;
    (async () => {
      let local = [];
      try {
        const raw = await Store.get(session ? 'zy_chats_' + session.uid : 'zy_chats');
        if (raw) local = JSON.parse(raw);
      } catch (e) {}
      let merged = local;
      if (session) {
        try {
          const old = await Store.get('zy_chats');
          if (old) { merged = mergeChats(merged, JSON.parse(old)); await Store.set('zy_chats', '[]'); }
        } catch (e) {}
        try {
          const s = await freshToken();
          const cloud = await cloudLoad(s);
          merged = mergeChats(merged, cloud);
        } catch (e) {}
      }
      if (!cancelled) { setChats(merged); setLoaded(true); }
    })();
    return () => { cancelled = true; };
  }, [ready, authReady, uid]);

  // حفظ المحادثات محلياً وفي الحساب
  useEffect(() => {
    if (!ready || !loaded) return;
    Store.set(session ? 'zy_chats_' + session.uid : 'zy_chats', JSON.stringify(chats)).catch(() => {});
    if (session) {
      clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(async () => {
        try { const s = await freshToken(); await cloudSave(s, chats); } catch (e) {}
      }, 1500);
    }
  }, [chats]);

  // منع ترجمة المتصفح التلقائية على الويب (إعلان لغة الصفحة)
  useEffect(() => {
    if (Platform.OS !== 'web' || typeof document === 'undefined') return;
    try {
      const el = document.documentElement;
      el.setAttribute('translate', 'no');
      document.title = 'AQLira';
      el.setAttribute('lang', lang.code && lang.code.length === 2 ? lang.code : 'en');
      let m = document.querySelector('meta[name="google"]');
      if (!m) { m = document.createElement('meta'); m.setAttribute('name', 'google'); document.head.appendChild(m); }
      m.setAttribute('content', 'notranslate');
    } catch (e) {}
  }, [lang]);

  const startMs = session && session.createdAt ? session.createdAt : start;
  const daysLeft = Math.max(0, 30 - Math.floor((Date.now() - startMs) / 86400000));

  if (!authReady) {
    return (
      <View style={[st.root, { alignItems: 'center', justifyContent: 'center' }]}>
        <Logo size={96} />
      </View>
    );
  }
  if (AUTH_ON && !session) {
    return (
      <View style={st.root}>
        <StatusBar barStyle="dark-content" />
        <AuthScreen t={t} onAuth={onAuth} applyLang={applyLang} />
      </View>
    );
  }

  return (
    <View style={st.root}>
      <StatusBar barStyle="dark-content" />
      <View style={{ flex: 1, display: screen === 'main' ? 'flex' : 'none' }}>
        <Main
          key={uid}
          t={t}
          rtl={rtl}
          daysLeft={daysLeft}
          setChats={setChats}
          openChat={openChat}
          openProfile={() => setScreen('profile')}
          openHistory={() => setScreen('history')}
        />
      </View>
      {screen === 'profile' ? (
        <Profile t={t} go={setScreen} daysLeft={daysLeft} lang={lang} applyLang={applyLang} busy={busy} langMsg={langMsg} session={session} onLogout={logout} />
      ) : null}
      {screen === 'history' ? (
        <History
          t={t}
          chats={chats}
          go={setScreen}
          onOpen={c => { setOpenChat({ ...c, msgs: c.msgs.map(m => ({ ...m })) }); setScreen('main'); }}
          onDelete={id => setChats(prev => prev.filter(c => c.id !== id))}
        />
      ) : null}
    </View>
  );
}

// ---------- الأنماط ----------
function makeStyles(rtl) {
  const R = rtl ? 'row-reverse' : 'row';
  const TA = rtl ? 'right' : 'left';
  const MEALIGN = rtl ? 'flex-start' : 'flex-end';
  const BOTALIGN = rtl ? 'flex-end' : 'flex-start';
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: C.bg, paddingTop: 36 },
    pad: { padding: 20, paddingBottom: 30 },
    row: { flexDirection: R, alignItems: 'center' },
    h1: { color: C.text, fontSize: 24, fontWeight: '700', textAlign: TA },
    h2: { color: C.text, fontSize: 18, fontWeight: '700', textAlign: TA },
    muted: { color: C.muted, fontSize: 15 },
    card: { backgroundColor: C.card, borderColor: C.border, borderWidth: 1, borderRadius: 16, padding: 14 },
    cardTitle: { color: C.text, fontSize: 15, fontWeight: '700', textAlign: TA },
    cardDesc: { color: C.muted, fontSize: 12, marginTop: 2, textAlign: TA },
    top: { flexDirection: R, justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingBottom: 4 },
    topRow: { flexDirection: R, alignItems: 'center', gap: 18 },
    topBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
    topLink: { color: C.greenText, fontSize: 14, fontWeight: '600' },
    brand: { color: C.text, fontSize: 26, fontWeight: '700', marginTop: 10 },
    tagline: { color: C.muted, fontSize: 14, marginTop: 2, textAlign: 'center' },
    free: { marginTop: 10, backgroundColor: '#E6FBF1', borderWidth: 1, borderColor: C.green, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 5 },
    freeTxt: { color: C.greenText, fontSize: 12, fontWeight: '600', textAlign: 'center' },
    rect: { flexDirection: R, alignItems: 'center', height: 58, borderRadius: 16, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, paddingHorizontal: 16, marginBottom: 10 },
    rectTxt: { flex: 1, color: C.text, fontSize: 16, fontWeight: '700', textAlign: TA, marginHorizontal: 12 },
    dot: { width: 12, height: 12, borderRadius: 6 },
    dock: { paddingHorizontal: 14, paddingTop: 10, paddingBottom: 18, borderTopWidth: 1, borderTopColor: C.border, backgroundColor: C.bg },
    chip: { backgroundColor: C.card, borderColor: C.green, borderWidth: 1, borderRadius: 18, paddingHorizontal: 14, height: 36, justifyContent: 'center' },
    chipTxt: { color: C.greenText, fontSize: 14, fontWeight: '700' },
    sendBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: C.green, alignItems: 'center', justifyContent: 'center' },
    sendTxt: { color: C.ink, fontSize: 20, fontWeight: '700' },
    input: { flex: 1, height: 48, borderRadius: 24, backgroundColor: C.card, borderColor: C.border, borderWidth: 1, color: C.text, paddingHorizontal: 18 },
    attachBtn: { width: 48, height: 48, borderRadius: 24, borderWidth: 1, borderColor: C.border, backgroundColor: C.card, alignItems: 'center', justifyContent: 'center' },
    thumb: { width: 64, height: 64, borderRadius: 10 },
    thumbX: { width: 24, height: 24, borderRadius: 12, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
    bubble: { maxWidth: '84%', padding: 12, borderRadius: 16, borderWidth: 1, marginBottom: 10 },
    me: { alignSelf: MEALIGN, backgroundColor: '#000000', borderColor: '#2A3558' },
    bot: { alignSelf: BOTALIGN, backgroundColor: 'transparent', borderColor: 'transparent', paddingHorizontal: 4, maxWidth: '100%' },
    meTxt: { color: '#FFFFFF', fontSize: 15, lineHeight: 24, textAlign: TA },
    botTxt: { color: '#1B2233', fontSize: 15, lineHeight: 25, textAlign: TA },
    action: { alignSelf: 'stretch', borderWidth: 1, borderColor: C.green, backgroundColor: '#E6FBF1', borderRadius: 14, paddingVertical: 11, paddingHorizontal: 14, marginTop: 8 },
    actionTxt: { color: C.greenText, fontSize: 14, fontWeight: '700', textAlign: 'center' },
    modalBack: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', alignItems: 'center', justifyContent: 'center', padding: 24 },
    modalCard: { width: '100%', maxWidth: 340, backgroundColor: '#FFFFFF', borderRadius: 20, padding: 22, alignItems: 'center', borderWidth: 1, borderColor: C.border },
    modalTitle: { color: C.text, fontSize: 18, fontWeight: '700', textAlign: 'center' },
    example: { borderWidth: 1, borderColor: C.border, backgroundColor: '#F7F9FC', borderRadius: 14, paddingHorizontal: 14, paddingVertical: 10, marginTop: 8 },
    exampleTxt: { color: '#24324A', fontSize: 14, textAlign: TA },
    chatWide: { width: 260, height: 146 },
    chatSquare: { width: 240, height: 240 },
    chatImg: { width: 180, height: 180, borderRadius: 12, marginBottom: 8, resizeMode: 'cover' },
    avatar: { width: 64, height: 64, borderRadius: 32, backgroundColor: C.green, alignItems: 'center', justifyContent: 'center' },
    authBtn: { height: 50, borderRadius: 25, backgroundColor: C.green, alignItems: 'center', justifyContent: 'center', marginTop: 16 },
    authBtnTxt: { color: C.ink, fontSize: 16, fontWeight: '700' },
    langChip: { borderWidth: 1, borderColor: C.border, backgroundColor: C.card, borderRadius: 18, paddingHorizontal: 14, paddingVertical: 8, margin: 4 },
  });
}

const STYLES = {};
let st = makeStyles(true);

const LOGO_URI = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUEBAQEAwUEBAQGBQUGCA0ICAcHCBALDAkNExAUExIQEhIUFx0ZFBYcFhISGiMaHB4fISEhFBkkJyQgJh0gISD/2wBDAQUGBggHCA8ICA8gFRIVICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICD/wAARCAFAAUADASIAAhEBAxEB/8QAHQAAAAcBAQEAAAAAAAAAAAAAAgMEBQYHCAEACf/EAFkQAAEDAgMFAwcFCgoGCQUBAAECAwQABQYHERIhMUFRE2FxCBQiMlKBkUJik6HSFRYXI3KSsbKz0TNFU1VjdYKUosEkNTZDZYNGVmRzdKPC4fAYJURUhNP/xAAcAQABBQEBAQAAAAAAAAAAAAAEAAECAwUGBwj/xAA+EQABAwIEAgYHBwMDBQAAAAABAAIDBBEFEiExE1EyQXGhsdEGFSJTYYGRFiMzcrLB8BRC4TRDkiRSYoLx/9oADAMBAAIRAxEAPwDHVdrteqKpXq7pXqEKSivV0CvAUICkokrgoQFdAoYTSUSUAChaUYEUINmmuoFyK0oWzR6WieVCDJ6U11AvCT7JruyaVBk6cK6GTSuocQJJs10IpZ2B6V0MHpTZk3ECRhBruxS3zc9K72B6UsyjxQkJRrXQg0uDB03CvCOelNmTcUJFsGvBNLvNz0r3m56UsybihIezNe2KX+bnpXvNj0psyXFCQbFeKKcPN+6uebk8qWZLihN+wa5sU4+bHpXDHPSlmT8UJvKDQCinIxz0osxyOVPmTiUJAUGgFNLlMkCii3T5laHpIU0HSlKkd1FlJp7qwORBG+uEUaU0Epp1YCi6CaHpQSKdSQCK5QjXCKSmvCu14UICkmXhQtK8BQwKSiSvAUMJrqUa0chs1G6pLkBKCaNS3v4Ue2wTypxjW9x0jRJNRLkNJMGi5TehgnlSlERSvk1ZWFMqsU4oSHbbaXFRx60l3RtlPitWg+FWfbcjbFb0JXiTFbRWPWYtzJdI7ttWifqNVl6yJsRYwXJ+unis4t29Z+RSlFpdI3IPwrULeF8rLUNhuwzrmofKlzdgH3IA/TR3b4JY3R8A2gAfyq3Vn9aoZisSTH4AbB47/JZcTZ3v5M/CjE2V7+TPwrTxu2Fk7hgWwj+w59ugG9YYHDBFiH9hz7dQLzzVBx6M7O7j5LNIsj2n8GfhQxZHuTZ+FaRN9w0nhgqx/RufaoH3xYd5YLsQ/wCWv7VVmQjrUPXbT19x8lnL7hv6fwZ+FCFif5tn4Vos4lw8BuwZYvol/aoBxRh8f9DbF9Ev7VQMpTeub9fcfJZ4+4bx4Nn4V77hPj/dn4VoY4qsOmgwbYR/yV/aoJxXYxwwdYfoV/apuMUvXB59x8lnwWF/+TPwoQsL/wDJn4VoEYtsf/U6w/QK+1Xvvusmmn3nWH6BX2qbjFL1uefcfJUALC//ACZPurpsL/Ns/Cr/ABi6ycsH2If8hX2qGMYWX/qhYP7ur7VNxioetzz7is+/cB8/7o/Cu/cB/wDkz8K0IMX2TT/ZCwa/+GV9qhJxdZz/AND8P/3ZX2qXFPNL1wefcVnn7gP/AMmfhQDYJH8kfhWjhi60cPvOw7/dD9qjUYstJP8Asbhz+6H7VTDzzS9ctG7u4rNCrE+n/dn4UkdtLifkGtUi/wCHJA0kYGsCxz2Gltn4hVdVbcsbsnYk4VftyjxXBmE6f2Vg0+d3P+fRXR41ETbiD5hw/a3esjuwFJ+TSNcUp5Vq24ZLYauyC5hnFDaHVerHubfZHw206p/RVV4tyoxPhfVdztLrbJ9V9HptK8FjUVITW3W3DX3bmO3MEEfUX71Tq2SOVJlt91SWXbltEhSNKanY5HKiGyArXiqA4XBTQpGlFqFLnG9KTLTpV4KOa66TEUA0cRRZFSV4KLNcNCIoJFOphdAoQrgoYFJMV0CjUJ30FIpQhPSolVOKEhHdS1iOVEaCuR2StQGlWRl/gC4YvvKYkYBqO2AuRJWPQZR1PU9Bzql7w1ZdTUtibclNuEME3jFN0bt9pgrkOneojcltPtKUdyR3mtIYey0whgiMiVd0s3y6pGujg/0do9yflnvVu7qeWnrHgiwiy4fZDSANXXDp2j6vaWefhwFV/eMRuPuqUt4nXvoEzFx9lcDW4y+Rxjg1PPqCmV6xq9IHZJc2WkDRKB6KEjoEjcKhMzEC1qJU4T76ik28Ek+lTDJupJPpVNoJWeyhlqDnmJJUvkX06+vSBy+q9uoY7cidTtUjXcSflVaGLVjwlo6lNV3tR4KpOq9K9uoYZ59qijPUedPkRjcLbyUyVe18NuizelD5dQwzT1oszT1pcNEDDG8lNFXtXtUUbyo/KqHmaetAMw+1TcMKwYa3kpibwr26Cbwr26h/np617zw9abhBT9XN5KX/AHYX7deN5X7dQ8zD1oJmHrS4QUvV7eSmgvCtPXrwvCvbqF+enrXRNPWm4QTerm8lNheFe1RqL0oH16hAmK040NMtXtU/CCrOHN5KeovB9qlTd4PtVAUTT1pQicetLhhCPw1vJWIxet/rU7xrzrp6VVc1PPtU6RrgoEelSMazJ8LaepW9b74pCgQup9Y8YPNNGOp0OMODRbDoC21joUncaoGHczqPSqSwroQQQrfVDo+sbrH4c9G/PESFYuJ8qMK4zjLl4c7GyXZQJ82Uf9GePRJ4tk/DwrMmKsIXbDd2ett2guxJTR9JtwaHxHUd43Vo6yYgU2pIUqpld7XYcw8Pi034BL6EkRZyRq5GPT5yOqTVAcWGx/nkujw/E2ynK72XfQHyPZp4rBchgpUd1N7qN9WbjzA90wffn7Vc2NlxHpIcTvQ6g8FpPMH/ANqr+QyUk7q0YpMwXZ08+YJpUjSiSKWOJ0pMoUUCtRrrok8aARRihQDwqSuC6KMSKCBQ0imUSUahNLGUanhSdoU6RGipYGlVuKDlfYKQ4YsMu93iLbYLPayJCwhCe/qegA3k9BWqGGLdgXC7dhthSpwDakP8C85pvUe7kByFQXKaxtWDDT2LJSAJUsKZiAj1Wx6yx4nd4DvojEd8U46vVeuvfWVK4vdlC8xxeufVVBpoToN0Xer4pxayV6++oTNuaio+lSefcCpR9Ko/Ila676ujjRlDhzWAaJXInkk76bXJZUTvpG6/rzolkKkymY6D6TriWx4kgD9NFBtl0sVMAEoXJPWk6pHfXLtGdtl3m2x46uxH3I6z3oUUn9FNxc38atARzIQlqpHfRZf76Rl2gldSsrxEErL560Ht++ku0a5qaVlMRhKS8etB7ak51HHd40HU8aVlIMCVdua52/fSTbrm3SspcMJZ2/fXC930k2q7qTSslwwlPbHrXQ930kOoGp4V4EngdaVkuGEvD560MP8AfTftGhBdKyiYwnRMg6caPS+etNAc76OQ5TZVQ6IJ6bkac6cGJJ3b6jqHTS1l7vpiEFLCFK4ssjTfUhhTSdNTUFYf0I308RJZBG+qi1YVVSghWXb5/Aa1NrJe1MuJBXu1qooEzeN9Sm3zCSN9DvYCLFchU07onZmq4MTYfgZjYQVbHyhNxYSVwZCvkL9gn2VcO7ceVY0v1pk2y4SIcthTL7Ky242oaFKgdCDWrcO3lTLiUFVQ3PfCzUqPGxlBaA7bRiaEj5enoL94Gh7wOtCxkxusV0uEYlxLNcdQsuvI0J3UhcTTxLaKVkU1uitZhuu+ifcJKRRZFHKotVXBGAryaNSKKTR6BvpiouSllJ1qWYYtL13vMO3Rxq7JdS0nuJOmvu41GGB6Qq4MnIiTip25LA2bdFcfBPJR9BP6xoWZ1gsHFajgU75OQVqYnnx7fDZtcLRMaG0lhoD2UjT/AN6qO7TytajrUixPcit9wbVV3Ok7SjvoKJt9SuHwijJHEfudUnlSSSd9NLr5JO+uvvak76b3HN9aDWruIYQAjVuE1ZeS+B5mKsbwrs/HULLa3kyHnlD0XVpOqG0nmdrQnoB3iq7tN8TZ5aZCrNbLnoddieyXE/UoVqzKnNayYxY+4rdvbs1yiN7Qht6dk4gcS1uHDmnTUa676HqnyMYco+aqrpJYIi5jLjny+Sp3PvBMzD2O5eIo8ZRs95c84DyRqlp9X8IhR5EnVQ669xqnVK61svNXNuwYKhmyv21q+XKW1tGA7p2KWzwU7qDuOm5Omp05cayFfb6zepqpLNhtdnCjr2VvaWhP+JR+rSpUj3vYMw+aKw+WSaIOc3TnzTbt10Ek0SFa1Y2U+WtwzJxci2tLVGt0cB6dLA17FvXgOq1HckeJ4A0Y9waLlaTtEhwPl3ivMC7/AHOw1bFySjQvPrOwywOq1ncPDieQNaowl5J+D7Yy2/jK7Sb5L3FUeKox46T01Hpq8dU+FXJh+02TCWH49gw7BbgwI43IRxWrmtZ4qUeZNLpFxjxIzkqZJbjsNjaW66sIQgdSTuArKfXAmzFUJWD4lMltypystTQbh4Asmg+U9FS8r85epom7ZP5U3totzsA2dOo024zHm6x4Kb2TUSuvlH5SWiSqMrFHnziTorzGM4+kf2gNk+4mpHg7N/L7HkrzLDWI2ZE3QnzR5KmHiBx0QsAq92tTzy2zEIjObXt3KjMyfJOSzDfuuWk96QtAK1WicsFau5p3dqeiV8farJ0hmRElOxZTLjD7Ky2404kpUhQOhSQd4IPKvq72vfWRvK0wDEYVb8xbawGnZLohXLYG5xeyS06e/RJQTz0TREM+Y5Sk17XGyy20lTiwlIJJ3ACtTZW+SlPvcJi95gyn7REdAW3bWNBIWnkXFHUN/k6FXXSmXyTcuouJMYTcY3iOl+DYihMVtY1SuUreFEc9hI18VJPKt2BVGBt1eyIHUqu7NkXlNYmUoiYGtj6kj+Emt+crV3kuE0uuGT+Vt0aLcvL+xEHm3CQ0r4oANexrm1l9l8sMYpxIxElqTtJiNpU8+QeB7NAJAPU6CotafKYycuskR/vnVBUrcFTYjrKPzinQe8in0V/sjRQ3GnkiYLuzDj+DbhKw7N3lLLijJjKPQhR20+IUfCskY9y2xflteE27FFtLCXCfN5bR22JAHNC+vzToocxX1DhToVyhNTrdLZmRXk7TbzDgWhY6hQ3Gm7E+FrFjLDkrD+I7e3Pt8lOim1jek8lJPFKhyUN4pWUHRNOy+T4VRqVVPM28r7nlbjh2zSVKkW18F63zCP4drXTQ9FpO5Q8DwIqFRWY69FyZzEVv2nCST4JSCT8KiTZASezuut7RNLmkL3bqcoVzwJbgFPw7tfXR8kLRCZP66z9VSCHmw1azpYcDWKBpwW4lb7g/tKINUuc/+1qypnzn8KIntIHjr3JvtmHr5cNkw7VMkA8C2wpQ+OmlSmJl/jJYBGHpoHzkAfpNFpz5xqogdnbUp9kRzp+tUgtef16QtIuNmgSEc+yK2lfpIoR7pxsAsOduI78Nv1v5JIMI4ohJ2n7HOQkcw0VD6taPireYXsLSpKhxBGhFW7hHNHDWJnG4ocXbpzh0SzII0WeiVjcT3HQ1NbhYLTeWSi4wW3VcA4BsuJ8FDfQ3HdezgsKXiPOWRtiqWts1SFJOu8VYrDTOKMJz7BII0mMFtJPyV8Un3KAqH4jwnJwzOQtCy9CdP4p3Tf8Akq7/ANNOWF55ZloBPE08hDhmCwiXUs4ftzWVr1DdizHmHkFDjailSTyIOhHxqOvDQmrhzltbcDMO5FpGy3JKZSf7Y1P+LWqikDRRo6E3avWcPl4kbXJvWKKNHLolVGBbbV1NKEUQmlDYpiovS6ONSKurLLSNhXEU3gpXm8cHxKlH9AqmIo9IVcWEXAzlldFDcVXBoH6NVA1GosuSx72qcs5keITPfJe28vfUQlO6k07XR4qdVvqNyHDqaeJtgnoYMrAiHV60icVvoxxdJlqosBdBG1BUaesG3p2wY6sl3aWUGNMbKtDpqgqCVg9xSTTApVFk1ItBFir3Rh7S12xT/jO9PYgxxerw84VmTLcKdTwQFbKAO4JAFR8mua1LcFZbYxzAlqaw1aVvsNq2Xpjp7OOyeinDu1+aNT3UvZY3XQBWMY2NgaNgoq2Rtb+FfQLJrCjWCcrrdGU0EXC4ITNmq03laxqlJ/JToPHXrVR2DyVoUNTMjE+LVynEqClxrfHCUHQ66ba95HL1RWjC6ANEjRI4AchXPYjWMeAyM35rEr61gs2M35orEGJbdhrD06/XZ/sYUFouuqG86DgAOZJ0AHMkVgvMzNjEuZV3Wqc+uLZ216xrY2v8W2ORV7a+qj7tBV5+VJepEfB1ksrSylq4TFuu6H1g0kEA/wBpYPurNmDcKzsZ4zteGLcpDcie92YcWNUtpAJUs6cgkE+7SiMMhaI+M7cojDWgxcd3X4KP6E8aPjSJESS1JivuR32lhbbrSilaFDeFJI3gjrW4o/ksZXosohvrvD8wo0M4S9he1pxCANgDXkQfGsk5i4Gl5eY9n4YlSEyksbLjEhKdntmljVCtOR4gjkQa1WTMk0aVqNla/olblyZx3Ix3lXbbvcFhdyZUqHMWBptuo09PT5ySlXiTTL5SCku5B3vaAJS9FUNeR7dI1+s1EvJdd7PKicnh/wDdnT/5bdP/AJQr23kXe068XI37dFY2YNqco5rCNQG1OQc0f5IaGmslZq0JAU5eXyo9dG2gKs/NrHDmX2VF7xRGSlcxhtLURKxqO2cUEIJHMAnaI+bVWeSYvZyUkj/jEj9RqnDyplbeQUsf8Rifrmui/tXStPsrBc+fOulzk3K4y3ZkyU4XXn3lFS3Vk71EniaKQopOvCpFgrCNwxxjW14VtRQiVcHg2Fua7LaQCVLOnJKQT7q2oz5IWWaLGmI7NvLk/Y0M4SQklenEN7Ozpry3+POq1SGl+yyxlRm5iTLG+tv259cm0urBmWxavxb6eZSPkL6KHv1FfRzDt+tuKcNW/ENne7aBPZS80ojQ6HkRyIOoI5EGvmPmJge4Zb5g3DClweTIVGKVtSEJ2Q+0oaoWBy3biORBFa78kS/SbjlxeLO+srbtk8FnX5KXUBRSO7aCj7zTDdKJzmvyFS/yj8CNY1yZubrTO1c7Ik3KIoD0vQH4xHgpG1u6hPSvm0TqdRwO+vsE+y1JjuR30Bxp1JQtJ4KSRoR8KzViPyN8Bz2FKw3fLrZZGnopdUmU0OmoUAr/ABVNEObfULCyDR6DVlZk5E48yxC5l0hIuFmB0F0g6raT07QH0mz47uhNVkkkUyFe226WNqpY0o02oVStpVQIQcjU+wZS2XUqSo6ithZQYmkYlwbsT3S7NgrDS1k71oI1QT37iPdWL2V6EVqLybG3Xbff5KteyCmWx3nRRP1EUBOzYrnq+AGzgFc98tCLxh6ZBUnVamyps+ysDVJ/y99UVapGxKTodN9aWYbG0CeHOsoQZqV3V4IOqQ6rTw1obKuVxikvG14+Kb882w5cbPOA3vQtknrsrP76oSUPSNX9nGoO2jDjnE9m+n4KTVCy0+kaLp9Aun9HZC6jYT/NU1ODfRKqUODfSdVHhdg1CTxpQ2eFEJo9uolM9OUUakVathXsZXXE/wDEmv2SqquLxFWZa1bOVs/f/GjP7JVByrlcYF2NH/k3xURuDpK1HWmN5eutOU1eqjTQ6eNXMC0aZlmhJnFb6TKVRjh30nUavC1mBcUaBrrXidakGCsLycZY2tmHIqi2ZjujjoGvZNAbS1+5IPv0py4NBJVpIaC47BWTktkwrHj/AN8GIu1j4ZjuFISg7K5yxxQk8kD5Shv5DfqRseIzBtVsYtlqiMwoMZGwzHYQEIbHQAf/AA86brfDg2W0RLPa46Y0GG0llhpPBKRw8TzJ5kk1EcxcxrXl9hw3GaPOJj5KIkRKtFPr068kjdqeXiRXJVFRLVyZW7dQXE1WJSVcvChG+wU8W/uJJ3DeT0qP3DGWFray47PxHbIyW/W25aAR7tdaw1i7MjGGNpa3LzdnRGJ9CEwotsNjoEg7/FWpqJpbOuoT79KMjwckXkd9FoMwJ7heaSx5Afv/AIVs515iQ8e4nitWgqXabYhSGXVJKS+tRBWsA7wNyQNd+4nnUXy6xZ94uYloxQY6pDUNw9s0k6KW2pJQsDv0USO8VFkppQxFflPtxYzKnn3lBtttA1K1KOgAHUkityOFkcfDGy3ooWQxCFuwX0ofxfZIeDvvtmTCxaPNUzC+tCtQ2oAglI1Ou8bu+sH5sY3RmFmRNv8AHjqYhBCI0VKxostI10UroSSo6ctdK1DmWEYf8mudapiklbNsjwNAfWc/Fo0HvB+FYsCPS4bqFpIwLuWZQODg5/xstX+Ta72OWE1PW6On/wAtunfPyUk5M3VtS9C49HSkdT2qTp9RqNZAu9jl3LT/AMRcP+Buo5n/AIkVLdtmFozm0hr/AEySAflEbLYPu2j7xWdwy6sPwN1zYldJihYOp1/kNVb3kodmrJqY2hYUpu7v7QB3p1baI1pw8qFJ/APLH/EYn6xqqfJRxSi0Y2uOEJK9li9tB1jU7g+0CdPFSCr80VcXlQNa5FSx/wBvin/Ga6IO0su8ZJdtwsbZX4yGX+ZlmxUqMZLUN0h5pPrKbWkoXs689FEjvAr6U2HFlixJhBjFdnm+c2p9pTyHghQOidQoFJGoIKSCOor5WFv06+gfk8LYu3k2263RlhKmhLiOfNWXFnf7lg++mUqeS5yrGGcmP2Myc07jieDHcYgKQ3GiJdGiy0gaBShyKiVK05agcqlvk+5vxcscSTI96bcXY7qlCZC2htLYWjXYcCflDRRBA36HUcNDUFztUyzXSVabhHXHlwnVR3mljQoWg7JHxFIdCOFMoFxLr9a+nkPOXKqc025HzBsYDnqh2WlpXvSvQj3ippBuMC5xEy7bOjzYyvVejupcQfBSSRXyMV2hOpBIqUYLxvifA15RdMM3d+3vAgrSg6tvDotB9FY8R4aU90RxrbhfVF9liTHcjyWUPMupKFtuJCkrSRoQQdxB6Vhbyi8g28ELXjXB0ZQw484BLhp3/c9ajuKf6JR3fNJA4EaahyfzXt2aWFTLCG4l5h7KJ8NJ1CSeDiNd5QrQ6dCCDw1M9ulug3m0y7Tc4yJUKY0ph9lY1S4hQ0IPuNONVb7L23C+SSTShtWlSTMbBkjAGY95wo+VLRCf/EOq4usqG02rxKSNe8Gouk0xQLx1Je27vGprduSGFXcOZU24Smy3MuJM55KhvTtgbAPggJ+JrKeSmX7uYGYkWLIZKrRAIlT1cigH0W/Fahp4bR5V9A0MAaAJAA4ADcKDm10WXUMzENCjuLbqjDuBbzeVqCTGirKNeayNlA/OIrHuHpJVKJ111NW55S+NW48eBgaC8O2WRMm7J9Ubw2g+O9XuTVIYacIeRv3VXk0usDFYhwiOSkuaytuw4dPzX/1k1R8wekaurM07WHcOnukfrJqlZnrGnhU/R3/SNHb4lNTvGkyqUOcaIVRoXaMQk0e3xohNKG+VMVF6c4vEVYsI7OVc46/xqz+xXVdxt5FWBGOmVM3+tWf2K6Ek3XMYpqGfmb4qEy1ekaa3VcaXSVekabXTRDQtiFuiTrNJ1GjVmiFGrgtFoXCa0J5MVpbcvV/v7iQVxWG4rRPIuEqV9SAPfWeCd9ac8mZ9sWHETII2xIZWR3FCgP0GgcQJEDrLJxyUxUL3D4eIWg1u/GsR5yYjkYkzTupW6TGtzhgx0a7kpQdFH3q2j8OlbRWvfr76w3mLaX7NmVf4byFJ1mOPtk/KQ4dtJ+CvqNZuFsAeT12XK+jDmvqXuduBp9dU14Uw+9ifF9pw8w6GV3CShjtSNQgE+krTnoATp3Vt+2ZPZX22zJtgwhBmo2dlb8xJcfcPtFeuoP5OgHKsM2S8TMP4ggXuAoCVAfQ+3tcCUnXQ9x4HuNaoheUvgl20iRMhXSLNCfSiIZDgKuiV7QBHedPCtadryRlXSYt/W3aaYEjrtvfyRM/yYsNO3OQ/CxPPhxHFlTUbsEOdiPZ2yrVWnUjX9NSrCGUmCMunVYgdkOTJsZJUJ9xWhCI403qSBolJ0+UST00rOOJc6sdX3EUufbb5OssFwgMQoz2iWkAaDU6b1HiT1PSoncsR4hv5Sb3fJ1yCd4EmQpYHgCdPqpcKRws5ypNLXysAmlAB3sNezq8Vamc+aTONJjNhsTqlWSE52intCPOndNAoD2EgnTXiST0qp22taLZbJNOcdjUjdRDWhjbBFNYynjEbNgrsyvvEbD2V1xuMskMsS3FkDis7KAEjvJ0FVq43PxTiV2bIBXJnvgqA5FRAAHcBoB4UoimZKs8ezpJTEadU/sD5a1aDU+AGg8TV25J4ANyxdGnvs6xoBEhzaG4keoPerf7jWY9wY85ek4rl4W8Kpe4avkdp8B/NT/hU3cbVcsC49fRb3lsTLPOPYvcwptfon6h7jWks4sVwMe+S03iC3FI7aZFTIZB1LDqV+mg+B4dQQedIM9MBdlf/ALvRmD2U9ILigNwdSND8QAfjVFKn3O1Ydu+HUHat9zLa3W1cEuNqCkrT0PEHqD3CpxVFnmN24WvBXmGWSnk3Gnkfmq1dZ0OulXd5P2cDOXl5kWe/rX971xUFOLSCoxXRuDmg4pI3KA37geWhqWQxx3U1OoUhWo3VoA3WlDMbgjdb8x3kll1nAlrE8aaqLOkIBF0tbiFpkpA0G2Dqleg3a7lctd1V8x5GeH0z2HX8bz3YyFgusiI2lTidd6Qra9Ekc9DpWUrTi/FOGnVOYfxBcbUtXreaSFthXiAdD7xUww35QWaNgxPAuk7FVxvMSO6FPQJb+rchHBSTu3HQ7jyOhqS12PY/Vw1W1XvJ/wAoHrAbP95EBtnY2Q+3tCQDp63a67WviawJmXg44AzMvWE+3VIbgvAMuq02ltKSFoJ057KgD3g1r17yw8tEWEzGrde3LgUboBjpSdvTgXNrZ0157/DlWLsY4suOOMb3XFd1CUyri8XVNo9VtOgSlA15JSAPdSVsoaRop/kBi5/CudFhcDpTGuLwtslOu5SHSEjXwXsH3V9GNSONfM3JqxSsRZy4Wt8ZsrCJ7cp4j5DTRDi1H3J08SK+lu2VHXmTwp2hNBoCsaeWHY2mcaYbv7aAlc6C5GcI5lpYKfqc091ZstVpn3q8RbTa4rkubLdSyyy2NVOLJ3Af/N3GtAeUxmHZMb4tteHMPazU2NTrbkxo7SH3nCgFDenrBOxpqOJOg4am4cgMkxge2pxXiWKPvlmN6NsrGvmDR+T/AN4oeseQ9HrrBx10Q8hu82Uzyoy2h5bYFj2ZGw9cXtH58lI/hXiOA+akeiPjzNPmNsWWvAeDZ2JLsoFuOnZaZB0VIdPqNp7yfgATyqRXCdAtFrk3S6S2ocKK2XXn3VbKW0jiSa+fmdGbcvM3FmsXtI9ggKUiBHVuKuRdWPbV0+SNB11oDblUuZl161Erzf7lijFE2+3V7tpk14vOK5AnkOgA0AHQCpNh46OIqBw9ygam1lXotFSeNLLncTF4yFJsx1bWG8PHoJH6yapqZvUat/H5KsMYfPdI/WTVQzOJqiJUej+lMB8XfqKaXONJ1caUucaTqowLsmLqaUtik6aUtcaYpnpzijeKsBvQZTTTz+6rP7FdQKIN4qecMp5f9bM/sV0K/cLmMS1LPzN8VX8k7zTc4aWyDvNIHDRLVvRDRJ1miFGjlmiTxq1HNRZ41cHk+3563ZhrtXZuOMXOOpCthJVsKR6SVHTgPWGvzhUFwRgu6Y7xUxYrZo3tAuSJCxqiM0PWWrrxAA5kgc62dhjCWH8DWVNpsEQNpIHbSF6F6Sr2nFc+5I3DkKzq2ZjW8M6krnPSKvp4KV0EurnjQfv8inpaqrvMjLa349iNvpfEG7xkFLMop2krTx2HAN5TrwI3jU8ddKnjjvfRWqz8lXwrKhuwhzd15PTVktNKJYXWcFkO4ZO5h298tDDzk1Ou52G4h1J+sH4gUi/BdmCP+iFy+jH762Qdoj1Ffm0StKv5NX5tbTJnu3XZx+ltQR7Ube/zWQU5ZY+GhOEbl9GP301S7VcLTL80ukF+FIA1LT7ZQrTroeXfWzthWu5tX5tVdnTKs33qR4stxCroJCVRWwR2iE/LJ5hJG7vOnSigStOkx19TK2Ms35KiY6NSNBrUgt0FbywAnWmiAplLyC6lRbB3hJ0JHjV45fXXK+M4yb1Zbo47rvWt9Ljf5qQk/poSolLRoiq2RzRYd6VZfZfXO/zUMxIilcCtwjRDY6qPL9Na9wthmDhaxt26IAtXrOukaFxXXw5AUThO44cnWZs4cdimIkD8WwAnY/KTxB8aklQpadoPGccxP0HYtDB8LiiP9U52d56+oD4efgmy+WSFiCzvWycjVpwblDihQ4KHeKyZmJlxccPylh+OVMqJ7N9A9BY7jyPdWxqacQz7Jb7O67f3YyIRGihJAKVd2yeJ8BSqqZr/AL0HKR1+asxfCYqq1RmyPb19VuR/mi+cdzt62FqBTpUZko0JFaMzFumUkl59dqtFzDp4KjvJZb17krCjp7hWfrm5HXJcMZCkNa+iFkEjxIAqNNK52hWNRvd0SQfiNk3RLTcbvNTBtUCROlL3pZjtFxZ9wqQKydzPc3owLdzr/Qj99Xz5NsnD4w7dIjDjab8uTtPoVoHFs7I2NnmUg7WoHM7+VaGYZUdPxSvzTWs2O4vddPCzS6+fn4Fc1Sd2Abwf+SP3072byfc2btLSz96Mi3oJ0L89xDDae86kk+4Gt+NtK5Mq/MNdmTYlotz9xuchuDCjoLj0iQezQ2kcSVHhTmP4orICq/ycyctOVVrelPSkXG/zEBMqbs7KG0Df2bYO8J1GpJ3q0GugAFU9nnn+5elyMBZeSlriuHsJt0jk7UkncWWCN+yeBUN6uCd28x/NfPC/ZmXT7wsvI8tNpludhqygiTdD7Og3pb+bxI3q0G6rsyO8niFgREfE2LG2ZuKNnaaaB22rfr7J4Kc6q4DgnqayepqWp9liacgcgPvYRFxpjWIDfNAuFAcGogjktY/ldOA+R48ND3O4W+y2qTdbrMahQYqC48+8rZQ2kcyaQYvxjhzAuHXr7iW4ohxG9yQd63l8kITxUo9B4nQb6+fucGeGIc0bmY527bh6O5tRrcheupHBx0j11/Unl1NRCYhsYsE8Z556TcyLiqyWQuw8KxnNW2z6K5ixwccHIeynlxO/hSrRJOppOCVGlLQ4VMCyGfzKd4g3ipdaDo4mojFOhFSu0K/GJqDxoudrxdpUpx2NcJ4eP/iP1k1UMziat7Gx1wjh898j9ZNVFN9Y0JHuhcA/047XfqKaXONJ1caUOcTSdVGBdixCTSlrjSZNK2hvpiovTtDG8VOnDplNK/rZr9iuoNDG8VOHxplNK/rZn9iuhHdILl8R6Uf5m+KrqQdVGkCzpSx8+kaQuGi2ro4hoiFGiyNTQ1ca6y0X30Mji4oJHvOlTOiLGgutc5IYaZwzloxc3GwLjfNJTqiN6WhqGkeGmq/FfdU6lTm2m3HnnEtttgqUtR0CQBqSTyAFFgIhwI8Fn0Wo7SGUjoEpCQPqqqM7b29bsvTEjrKV3KQmMog/7sAqUPfoB7zXOsYZ5Mx6yvCpp5MZxMMaem63YP8AAUFx3nneLhNet+D31W+3oJT52Ejtn+8a+onppv7xwqq3cR4ikOFx+/XF1ZOpUuU4SfrptCasrKnK5zMO5ynJUxcG0QdkPutpBcWtWuyhGu4HQEknXQabjrW61jI26BewxUdBhdPcNAaNyRcntO5/llBBer2eN4nf3lf76MF5vR/jid/eXP31o7E/k32Q2N13CFxmoujadpDE51K239Pk7QSkoJ5HeOunGq1RkNmeRr9wWfDz5n7VOHsKaHEaCZuZjmjtsD3qAou9453ad/eXP30ZH84lSAkdpIfdO7itaz+k1adl8njHEyWkXlUK0RQfTWXw+sj5qUbtfEirlg4ewTlLh5c1TrUMAbLk+SQp99XsjTeT81I/fUXSgaDVZlfjNNT2ZCM7z1N8/K6zkxg7GAjmV96t47EDUr8xd0/VocKQ5Fc2VhSFpOhSoaEHvHKra/8AqFsbVxSmLZbk4wFb3+0QhXiE/wDvVnsMYDzlw2m4vMplKTq0JjaQ1LirA4E8+OuyrVJ5dag72h7QQZqZHj/q4SwHr3Hz5KqME42n2W4szIsxbLiOYO4joRzHdWxcEYxh4vsSZrOy2+2Qh9oH1VdR3Hl7xyrC2MMJXjAGIvudOPbxXQXIs1tJCJCAeI9lQ3ApO8d4IJn+TWO1WfGkNh98piTCIzgJ3ekdEn3K0+ugWtdTyZm9E7j91XSOkw+oDmH7t246u0fzUfJa4xRieDhaxvXOYoHZ9FtvXQuLPBP7z0rHOPcwLlfri4/MlFzXUJSNyUD2UjkKk2euOnJmKl2Vp38Rb0hGyDxcUAVH9A91VHhTDV9zDxW1YLK2FvL9N15evZx2xxcWeQHxJ0ApSNdUya9EdX7qytdLiVTl/wBtuw5nmf2/yo3OluSHNAokqOgHU0IYKxnLjKlx8JXp6OBr2qLe6UkeOzvrcmDsr8B5W2Zd0eTHemRmy5JvNwCdUAcSnXc0nuG/qTTLK8p7KuLchDTcLlJb10MpmEoteO8hRHgK0WRhgW7BRMibZxssIOpmQZJQpD0WQ0d4UFNrQfqIrjl/xAPVvtyHhMc+1X0Qu1jywzywn50FxbvHPoNXCIdmTFV02tNpJ+aoaHpWGszMDQcCYwkWODiaDfm2tdpcbULY3+o6PVC+oBPfpwq3ZFlpj1B0UNOIcSa7sQ3Qf/2u/aqS4NwrmBmnek4cs78+4p1St9cmS4qPHTruW4SSB3DeTyBqyMpvJwxBj7ze9X8vWLDiiFBxSNJEtP8ARJPBJ9tW7oDW3MNYXwzgPDCLVYIEe1W2MkrWQdNdBvccWd6j1UTTouNrni50ChmUuSeGcq7aHY6Rcb88jSTc3UaK05obHyEd3E8yeXM187sL5XwVRn1i44gcRtMW1pWihrwU6r/dp+s8geNVHnD5UzENMjD2WbqH396Hb0U6oR1DAPrH553dAeNZQtlytdxxgxMxvKuMm3vv7c55he1IWDxVtK11OvHnprpv0pr9QUnSW9mNWAUZleUNjoypjxcbaOyqQpJREtzZ+SkdfmjVSuJPMTLODIe04Oyih4hw+l52VankouMh06qlNuEJDhHBOyvZAA4Be/XTWtM4Ns1ihYbt7OGWYzdmLSXIvm3qLQoahYPEkjeSd550644srN7ywxPZXUBSZdskNjuV2ZKT7lAH3VdkDQnYzmvl+jjStqkbZ2kpV1ANK2qghJE6xd5FSm1HRxOlRSKeFSi1n001B+ywK0eyVLcZnXB+H/GT+smqmmesatnF+/BmH/ypP6yaqeZ6xoKPcoLAvwfm79RTQ6KTqpS7xpMujAuwYhJ40ra5UkRStqmKi/ZO8LiKm8k6ZSyf62a/YrqEQvWFTaZuykkf1s1+xXQjukFzFf8AiR/mb4qtnzvNIV0sf4mka6Maulj2RCqOgrDc1pz2FhXwOtEKrrKtl4E07tkSRdpC3Mt8PsofQoFLiQsEdCNaqXO+3uzcER5jYJEGWla9OSVpKNfjs/GpNl1fkXzAUAlwKkQkiK8OeqR6J96dPgafbhDjXGBIgTGg9GkILbiFcFJI31jwjhu7F8+Urn4ViAc4axu17Nj9RssXkaVeOQmP7Lh03LDt7ltwETXUyI8l07Le2E7JQpXydQAQTu3EVBcZZc3rC8px5hl2faidW5TaSooHRwD1T38D9VQNWzv9IfGtbR40XuDhTYvSEMddrusdX+fgVuHFOZ+FcLWR64vXaJNfCT2ESM+lbj6uQ9EnQdVHcB8KqoeVHI3EYLb/AL+f/wDOs4gJB9ZPxFGJA4jfTCJvWgab0co4W2lu889R4FX/AHPynb9JjKbtWGIEJwjQOPvLf2e8J0SPjVQX7FF/xXc/ujiC5uznxuTtnRLY6ISNyR4CmmJDkzZKIsKM7Jfc3JaZQVrV4AAk0qnWu52mQI91tsqA8oahuUyppRHUBQGoqQY1uwWnBQU1MbwsAPPc/U6oDZ0q9fJuvD7GY71kS4fN7jEWpSORW3opKvHTaHvqhkq0q4PJ0c0zuthP/wCtK/ZGncLhVVsYfC4O5LXmNsExcbYJmWF4JRJUO1iPqH8C+B6KvA+qruJ6CsOty5lnvBbfQuPJhP7K21blIWhW8HvBFfQpD4041i7yirQ3Z83X5sdAQxd46Ju7h2m9DnxKdf7VVZLixWRTNa9vDUPxJiR2/YkuF3c11mSFvbI4jaUSB+gVuHJrADGAMBMJkMpF7uKUyLg5zCiPRa8EA6eJUedY0yTsjWJ85cP2+U2HIjLpmPpPApaSV6HuKgke+voKp/qdeZqbIwNlqQRNi2WafKwxVMaFhwkw6pEV9C58lIOgdIVsNg9QCFHTrp0rJ61FRJ61ePlL4ismIcxLcLJdI9xTBgGPIXHXtobc7VStnaG4kAjXQnpQcr/JzxTjnsLtfe0w9YF6KDjqP9IkJ/o0HgD7St3QGpHdXFjnv0VbYFjY6uF+XZ8BuXMT57RZdRAdU2VtncdtQIAT3qIA61rrKjyaLLhRTF7xopm+XlOi0RtNYsZXHgf4RQ6nd0HOrgwbgbC2AbIm04YtbcNk6F1w+k6+ofKWs71H6hyAqns2fKZsWE0yLJgxTF6vadULka7UaKrxH8IodAdBzPKm0G6NbEyMZpFbeOcwsKZdWM3XElxTHSQQzGR6T0gj5KEcT47gOZFYUzaz+xRmS85b2lKtGHgr0Leyve70Lyh65+b6o6HjVbYmxVfcWXt+83+5P3Ce+fTdeVru5JA4JSOQGgFR8hSjwNLdJzzJ8AurdKjvNcSCTXQ2ongasHLPK3EWZN+biWqOpq2trHnlyWn8VGTz3/KXpwSN5PHQamnUfgFsbycfO1ZAYeMvU7KpCWSf5IPL2fdxqzcQy2oGEL1NeUEtR4Eh1RPIBpRNBsdnt+HsPwLFaWexgwGEx2EE6kJSNN55k8SepNVf5SeLmcL5I3OEl0JnX4i2x0g7ylXpOq8AgEeKxV+wRY0C+fbOvZo7kj9FLGjvpIjjSpvjVaCkTnGO8VJrWr8YmoxG4ipHbD+MTUH7LBrB7JU0xZqcF2D8qT+smqpmD0jVrYp/2JsH5Un9ZNVXN9Y0CzpFZ2B/hf8As79RTM7xpMqlLvE0mVRoXYsQkcaVs8aSIpW1xqJUX7J5habQqaz92Uj/APWzX7FdQuCPSFTS5ajKJ3+t2v2K6EPTC5ev/Fj/ADDxVZP8TSNdLHjvNI1ijQuoj2RCqcIttUbPKvEgFMVlYYb/AKV5Q1CR4JBUfcOdCtFpmXu8RbXAb7STJcDaBy1PM9wGpPcKk2ZyYlouduwbbVhUSyxwHFDcXX3NFOLPeRs+HCq3P9oMG/7KiWp+/ZSs6Trk/Bo3PzNgO0nqSfAeOX8IX0PrC3oD4DclpPEp5KHzhxHXeOdacgXCFdbezcLdJRJivp2m3UHUKH+R6g7xWLKkGGMaX/CUpTtpl6MuHV2M6NppzxHI940NRfCHajdc/j3o03ED/UU5DZO53b8fj8uzXJOnA6U3PWm0vLK3rVCcUeKlxkEn3kVWlrzyskltKbxa5UF3mpjR5H+RH11NMP43w3iiU5Es81bz7TfaqbWypBCdQNd40O8iqcjhuF5tNhOIUV3SRuaBuRt9Roljlisx/ieB/dW/3Vm/MJpmNmJeGWGW2W0up2W20hKU+gngBuFajVvFZizPZcZzMu+2NA4ptxPeC2nT9FXRbrp/Q+Vz6x7XG/snxatGeT5Z7bbMtmr7HbQbjcnXe2kaemlCFlKWweIG7XTmTv5VMcxrXAxNl9d4VzbQ52MZyQw8veWHEJKkrSeXDQ9QSDWW8uM3LlgKO9bHYQuVpdcLvY9psLZWdxKFaEaHQagjlrurQ0S+2TMnAD5jvuph3BpUeQhC9l1hR4pOnMcehHcaTmEOzIrFoqujrP6qQnIXaOHUOXyH1WOUq1AJ3EjXSrY8n13s857con/8aT+yNQjGGDbrg28LizR20RZJjzEjRDyf/Srqn9I31P8AICzzncefd8MqTAhx3UF4j0VrWNkJB5nTUnp76I3XZVdRE6jdMxwLSND2rZQm9DWavKkUhcvCkgD0+zktk9wU2R+k1aWJMfYbwjHDt9uiGHFDVEdHpvOfkoG/3nQd9Z4xliTEGd2J7dacK4UlPCFt9i23+MdUF7Oq3D6rafRHE6d5qRsAsDCWyvlbJb2ddfkickMd2HL/ABnccQYgEhaU21xmO3Hb21uuqWj0RruG4HeToPqqeP4vzhz/ALm9Y8LW5dsw6VbDwZWUMpT/ANof+WfmJ/NNTHLfyVLfBLV0zHmpnvblC1RFkNJ7nHBoV+CdB3mtOW2Hb7TbmLZaILECEwnZajx2w2hA7kjdVBlA0C6k5LqqssfJ1wfgIsXS7bOIb6jQh59vRiOf6Js7tR7StT00qz8V40w5gmxrvOJbm3BjDUIB3reV7KEjeo+Hv0qo8zvKIsGDUP2vDfY3u9p1SpQVrGjK+coeuoeyn3kcKxrinGGJMb3xVxvc+Rc5zx2UDTXZHsIQNyR3AVDiX2T8e2jArPzZ8o3EeOO3s9jLljw8r0Syhf4+SP6VY4A+wnd1Kqq/L7C33949g4fckqjR3Qt191ABUhtA1Vsg7tTuA8deVRWazKivqZlx3Y7o4odQUKHuO+j8P4huuF8Qw77ZZPm82IvbQojaB3aFKhzSQSCOhq5oF7lTDSTdy27bcmcs48RuL950GTsDTtpRW64rvKir9GlP0fJnK1SRt4CtB/5avtU15QZk27MrDzj6WEw7vCITNhhW0E6+qtBO8oVoeO8EEHkTayN1G2aRoEQ26iMXJ3KuM6l5rL+y7ad4KmCsfBRIqdRIsWDEbiQYrMSM0NEMsNpbQgdyUgAVGMQ4/wAF4PfZj4nxPAtL7zfattSFkLWjUjaAAJI1BHuqrsUeVXltZWVpsIm4klgEJSw0WGde9xwA6eCTUNArFed2vFssNmlXm8zmoNviILj8h46JQn/M8gBvJ3CvndnJmjKzSx2q5oS4xZoSTHtsZfFDeupWoe2s7z0Gg5UizIzexhmfPSq9SkxrYyraj2yLqlho+0dd61afKV7tKgiBVZddQcdEagUrbFJ0ClTYpkG8pfG4ipFbfXTUeY4ipBb9yk1W7ZYtX0SpriffgiwflSf101Vs3iatLEW/AthJ9uT+umqunesqgWdIrLwT8M/md+opkdG+kyqVO86SqowLsWIaONK2eNJE8aVs8RTOUZNk9wdyhU0u27KJz+t2v2K6hkEekKmV31/BI5/WzX7FdBnphcvXfjRfmHiqwd4mk+ySd1KHBvNGwIq5UxthpO0taglI6k7gKMvYXXTB2VtyrxyPwklm2zMXym9VrJhxNRw4dosfUn86qQxlJXOx1fJazqVzXdPAKKR9QFbZasbeGcJ2qxR0hPmTCG1afKXpqs+9RJrGuPbS5acf3uItJCfOVuoJ5oWdtJ+CqyqKbizPeevbsXJ4NVcfFZ3v3sAOwH/4oiRQCKOUmiyK2V3gKLqdZU3dFpzDhB5YQ1NSqIok7gVer/iCfjUHIryVLQsLQopUk6gg6EHrSIuLKirp21VO+B2zgR9VtNQqqc2sGyLvEaxBbGS7Lht7EhpI1U40N4UBzKdTu6HuqRZfY2ZxbZEtvrCbvFSEyW+a+XaDuPPofEVK5MhiM2XZL7cdA37bqwgfE0KLtK8NgfVYRXbe202I5jyI2+qxxpqKkeD8X3PB16TOgq7RheiZEZStEPJ6HoRyPLw1qZ4/by8nrel2iWW7tqSsQWtplw9Va6AHvSfcaimF8vMYYykhrDtikTW9dFSANhhHi4rRI+OtEZgRcr2GGphxClJnYWtOhDhb+fA+CvORmjgxWHm5785LyJA18x7MOO6jilSOA06nd0qHqzJxxi+5Jw/l1Yn4yinZSmG12r4HXUDZaHf9dWPgnyV7dG7Kbjy8mYsbzb7coob8FOn0lf2QnxrRWH7JYsL2xNsw5aItriDi3GbCdo9VHio95JNDuqGN6Oq5qnw/DKJxLLyG+l9h8uv5rOuB/JZmzpCbzmdenO0cO2uBEe7R1Z/pXzr8E6/lCtNYew/YMKWpNpw1aI1rhp4tx0abZ6qPFR7ySaPdfajxXZcx9uNGZTtOOurCEIHUk7gKoDMHylbZbUvWzATaJ8sapVcn0fiUf92g71nvOg7jQpkfItkTSy/AK8sUY0w7gy1/dHEdyRFQoHs2h6Trx6IRxPjwHMislZmeUDiDFqXrXZiuy2VWqS00v8c+P6RY5fNTu661Vk68YkxriEOPPTLzdpqwhI3uOOE8EpA5dw0Aq88v/JoemOs3HHs0ttblfcyGv0j3OOjcPBGp+cKtZETurg3/ALiqIw5hjFGOb0LThe0SLnK+UlpPoNDqtR9FA7yRW68jcmo2WOGjIu7EOTieYoqkSmvT7FHyWkKIBAHEkAak9AKPu+MMsMjsLNRpBiWlnZ2mLZAbCn5B6hA3n8tZ076pKL5abgxVIVNwWPveUkJZQzI/0tBB9ZRPoK1HyRpp1NFtaAtSBoAuAr5z1wNYsZ5R35y5RmROtkJ6bDmFI22FtoK9Nrjsq00I4HXqBXzM46Ec99aTzd8qaRjrCknCeFLK/aIE5OxMkynEqedb5tpCdyQeZ1JI3bqzihJVViueQrl8mWfIh54worRPZT4clh4cikI7QE+CkCt1isl+StgqQ5f7jjmU0Uw4rKoMVRH8I8vTtCO5KN3ivurW3LdV8fRSZqFi3yvHR+EqwtBXpJtAJA5avuaforOIG+rc8ovELeIc9LyI6w4xbEt21CknUEtj0/8AGpfwqp0iq3alWE2CEkUegUBKaf7XYnbhYbzdU6hu2IZWvTh+Mc2BUSQN0LLIGi5/l9E1oFKmxRKU76VNpqSGeUrYG8U/QPWTTKwnfT5AHppqDtlj1R9kqZ4h3YEsP5cn9dNVdOHpGrTxEB94dg/Lk/rpqrJ25RoBnSKzcF6B/M79RTK7xNJVUrd4mkqqMC7FiEnjSxniKSp40sY4iouUJNk9wPWA0qZXcaZSObuN2a/YrqGwfWFTa7J2spFf1s1+xXQh6YXLV340X5h4qrXB6VTjKS3N3PNTDkR1IUhc5oqB5gK2v8qhTyd9TDK28MWHM3D10lKCWGJzSnCeSdrQn4E1dNcxmy6CTWOy2hiKOpTiiRz1qksycukYviomQVIYu8ZOwhS9yXkcdhR5aHXQ8tdOHDSl9tu0pWg1HWoJLtykLJ2a5WKR0L9NwvNq2OegrONFoQsI3qwXawzFRbvb3oTo5Op0Cu8HgR3g0zlB6VvGVAZkMqYlR232jxbdQFpPuO6o49l1geUsrfwnbFKPEpZ2P1dK3I8RBHtBb9P6XNAtPEb/AAPnbxKxcUHpXEoK1BKRtKPADea2kzlvgJlYU3hC2aj2mtv9JNSO32e1W3QW60woen8hHQg/ECrv69vUFc/0xiA+7iJ7SB5rHWHsB49ujyHrHh+5gncJASphIB+erZGnvq07N5PGKbqtD2KsQR4SB8hClS3fidEj4mtHNB1emup8aXMxH3DuSaqdWOO2ix5fSWsnd90wN+Vz9T5KA4ayUy8w+tt9y2KvMtGh7a4q7Qa9zY0R9Rq1IxS2yhiO0lppA0ShCQlKR0AG4VxEBuNFXMnvtRYzY1W88sIQkd6joBVa4p8oHL/C4cjWPtMTT0jQebHs46T3ukel/ZB8agDJKeaup6aurDnlJt8VbzEZ1zeRoANSTyFVdjjP3A+DO2g2t0YjvCNU9lFX+IbV893eD4J1PhWb8W5qZkZoyF2xDz7cBf8AFtrQUM6fPPFX9s6d1I7Tk/fZjjSrvOjQY50KktEuuAdBu2QfeaKbA1urytstocPF6mQA9/03SfGuaOM8xZ6GrrNcWyV6sW2IkpZSeWiBqVHvOppun4Iv1uwm/iK6hMINrQhMVe91W0rTU6bk6dDv8KvaxYWseG2tm1QUNOEaKfV6Tq/FR3+4aCornHMZjZfiOpQDsqU2lA67OqifqHxqQdqA0aLHj9InVVZFTUrLNLgCTuRfXTYadvyTv5LFjhzJuIsQLQFTIgaiNEj1ErClLI7zsgeGvWtR3O5N4ewzc7yWu2ECI7KLft7CCrT36aVmTySrmx2OLbYSA+VRpKRzKQFoPwJHxrTjxZkR3Y77aXWXUKbcQrgtJGhB7iCRWixlwu1dF96Svmbfr7dcT3+ZfrzLXKnznC664s67zyHRI4AcAAKbQ2TV84y8m/F9qvEhzCcZN9tS1lTKW3UofaTyQtKiNojhtJJ16CkuHvJuzHu0pCbnCjWCNqNt6a8lSgO5tsqUT46DvqOUg2stC56lS7bNXllj5PuJcXPR7riBl6w2A6L7R1OzIkp6NIO8A+2oAdAqtE4ByPwPgUtTUxPu1eG9CJ89AV2Z6tt70o8fSV31aSllRJUSSeJPOptiJ6SWW/SSKz2m2WCyxLNZobcO3xGw2yy3wSPHiSTqSTvJJJqKZr5ixMtsv5d6UtCrm8DHtzB4uPkbjp7KPWPgBzFKsd5i4Xy6sRueIpuy4tJ82htEF+UockJ6dVHcPqrA2YmYd9zKxW5e7yoNNIBbiQ21EtxWtddlPUniVcSfcBa5wAsFaFEnXXpMhyRIdU686orWtR1KlE6knvJrqRXEppSxsJdSpxvtEA70bRTtd2o4VQq3OXm0FRAAJJOgA5npWussMoXG8mL3ar80YtyxK1tFKx6UZKRqyFDqFekR36cRVYZX47yzsN1j/dXBqbdLChs3VTypYaPUhQ1QO9IOlbDgPsyY7Uhh1DzTqQtDiFBSVpI1BBHEEUHM92gtZchiddNnEWQtF73Ntbdlx3r533Wy3Kw3mVZ7vEXFnRVlt1pY3g9R1B4g8xRTaa1PnJjvKlctyzXbDgxReooLRcjudgYp9gvjfqOaQFAc9DWa5i4EiYXLbb1wY54NLkF8j+0QP0UUxxcNQtNkxkYHEWRbKd4FPcEEKTTay3ppTzCaOop3bLOqXiylWIP9hLD+XJ/XTVWziNo1aeIk7OA7Efnyf101Vc31zWe3plCYL0D+Z36imZ3iaTK40pd4mkyudGBdgzZCTxpY1xFI0mlTRqLlF6fYB9MVP5jReylm7I17G5R3D3AoWmq7gq0UKtbDTH3WwLii1IG04YaZTaeqmlhW73a0DJo4FcpifsuY/k5viFTkhBBNJUOFtwKHKnaW1vJA3U0upINGNNwuiicHBbaySzns2L8PwsI4mnIiYhithhh19QSmcgDROiju7QDcQfW01Gu8VbM+wnbV6B+FfMYOrbVqk6VZOGc+szsKxm4kDEz0mI2NEx56EyUAdBt6qA8CKz6igbIbhRnoo6htpB81tCRYFan0KRKsTg4INZza8rjHqUaSLFh+Qr2iw6j9DlIZvlX5hvpKY1tsMPvREWsj85ZH1UB6tlGxWC/0aiebgrTSLC4SNUmlDtrh22OZVzlMQWE8XZLqWkj3qIFYru2f+a93SpDmLn4javkQWm4/1oTr9dV5cbxc7vJMm63CTPePFyS8p1XxUTRDMMf/AHuVkXovA03ebrb16zpyow2FoF8N6kI3djbGi6Cfyzoj6zVVYj8qe8PJWxhHD0S0t8BImHzl3xCdyB/irNRcJ50ErNaEdFEz4rcgwqng6DVLcSY7xPiyT2+Ir7LuSgdUpec1Qj8lA0Sn3CnTBZwLLdS1iR59ExStEh9ezGPTeneD+UdKrzaNcJovKLWCIqKITxGMOLfiDYrYNtgQ4kFtuAwyzF09BLCQEEdd24+NOACQN26sg2vEl+sm603eVDTxKG3CEn+zw+qnteZ2O3GuzOIXgOqW20n4hOtUmE8157P6G1bnkslaRzNwfA+K0pd7xbbFblz7tMbiR0j1lneo9Ejio9wrM2O8ZP4wvwkhCmYMcFuMyriE671K+cefTQDlUdnXK4XSSZNymvzHj8t9wrP10lq1kYbquowX0ciw13Ge7NJz6h2eamWW2OpeXuOoeIY6FPMJBZlsA6dsyr1kjv3AjvArfeH8SWfFNjj3uxTkTYMgapcSd4PNKhxSocwd4r5pVIcLY0xRgu4Gdhq8P29xWnaISQpt0dFoOqVe8USx+XddQ5gOq+kiT1o1K+lY2t/lU40YZCbjYbPOWP8AeAOMk+ISrT4Uku3lRZgzWltWyHabQFDTtGmFPLHgXCR9VXcRqjlK2fcrzarHbHLnerjHt0Jv1n5LgbQPeeJ7hvrOOYflURWEO2zLmJ5y9vSbrMb0bT3ttHerxXoPmmsxX/E+IsVT/PsRXmXdJHJUh0qCe5I4JHcAKaQmqjITsp2sl95vd4xHd3rtfbjIuM986rfkLKlHu7gOQG4UjSmvBNGpTUFEuXkijkivJRR6UU6Hc5eSk1oDL3MmbY8gcTQ0PqTPtS22Le4TqUCQSE6fkELI91UMhvupzjSJLMGRCbXoxIUhTifaKNdn9Y1FzA4arNqo2zNDXdRB/nyRKUqUvaUSok6kk6k+NL2G+G6gNNE8qco7G8bqsshZZbIxhnup7htbOm6krDBOm6nmOwdkEJ1NQdssGpm0TnixPZ4Hw4g7ipEh34u6D9FVJNPpGrjzPSmCbVaANFQYDTSx88jaV9ZqmJivSNZzNXEorBReK/MnxKa3eJpKulDhpOqiwuvYupNKWzvpImlCDpTFJ4TvEXooVa2Wl0agYphKf0LDiuxdB4FChsnX41UMZeihUrssotPoUDpoaCmbcLncTg4kTmpwxrh1eHsUXC0qSdhl09ko/KbO9B+BFQeSzoTurRWL7YnGGAoWKYydufbm+wlgcVNj5XuJ18FHpVHzYRST6NPFJcIXDK7ixjNuND2qKuI30nUKdn45BO6kS2u6jQV1EcgKQkUWoUqUiilINSRIciNK4RRpTQdmnVgKLr1D2a5s06ldArlD2a9s0k90CvaUZs17ZpJXReld0oezXdmkmzIvSu7NGBGvKhdnTpi5E7NCCaODdDS3v4UrKJeiQihhFHhqjEtd1PZVGREJRRqUUoSyTyo9DHdUrKh0oSdDfdSpDJ6Ue2x3Utaj7uFSAQkkySts91LWo+um6lLUbU8KcWIh1G6nss6WoASZiNw3U6R4x3bqVx4Wuno07xoJOno09liT1YCSxYpOm6pjhKypuGIYqHU6x2D273TYTv8ArOg99IY8HQDdUvlFOE8BSJLg2J9yGwkc0t6bh8N/vFDTOyNJXOVNU53ss3Og+aqbMC7G6YknS9dQ44SPDgPqqtJa/SNSC7yS68pRPE1GZCtVGgom2Gq9AwyARRNYOoJG4d9EKNGLO+ilUWF0DQvJNGoVvogGjEmkVJwS9le8U9wZGysb6jraqcI7uhG+qHtus+ePMFe2WuKUW2d5rMUDDlDs3ArekdCR03kHuJpPj7BP3GnmTCbKrZIJLKhv7M8Sgnu5HmPfVb2u4FpaSDpV4YNxVCu9t+9u+bLrbidhsuH1hyTryI+SfdWeQWOXn9dHLQzGpjF2npD91Q8yAUKPo0yvRyCd1XZi/Az9pdU+yC/BUdEPab0/NV0P1Gq3m20oUdU0UyRdBQYlHOwOabqHLZOvCiFNVIHohHKka43dRQct9k4KZlN91Fls9KdVxz0oks91TBRQlTfsUHs+6l5Z7qD2J6VK6sEiRbHdXtjupZ2O/hXex7qdPxEi2K7sd1Lex7q72PdTqPESLs+6hBrXlS3sO6hJZ7qdR4qRBqhhqlwY7qMTH7qdQMwSENd1GBk9KXJj91HoinpT2VLpwm9LB6UcljupyRF7qUtxO6pWQz6gBNrcc9KVNxteVOSIfdSxmFryqVkDJVBNjcU9KXMxDu9GnRqCfZpyYt53ejUgFmy1gCamIfD0ado8A7vRpzj246g7NPcS2k6ejT2WJUV4HWmqLbySPRp8jW8jT0adotsA01TUnttgS4lMiUChjkOCnO4d3fTOIAuVzc9fmNgU3WKxNKJuU4JTDY1V6W4LI37/AJo5/CqwzGxWbzdllpZ83b9Fsd3X3/uqT5hY7ZUhVltK0iM36Li2/VXp8lPzR9Z+ujrjNU64olWutZMr+K6w2C38Ew58jxUyjsH7/NN817aUd9NDytSaUPuak0gcVrVrRZelwsyhFqNFE0JRosmrUc0LgoYNAFCBpKRCPQqlTS9DSFKqOSqoEKh7bp8jP7JG+pJbriW1J9LSoU07pzpxYkkEb6Gkjusmppw8WK0PhbHseRGTbb8sLbUnYD6xtAjoscx3/HrR+IcvWJjZmWNaNFjaDClapI+Yr/I/GqMh3FSNPSqc4dxzcrPohl4Oxyd7Dm9Hu6HwoMgtOq4CrweemkM9CbHrHUfL+bJludgkw31MSYzjDg4pWnQ0wvW8pJGzWgImL8LYijJj3RDTCzu7OUAUa/NXy+qiZ2XFknI7e3SXY4VvBBDrZ8Of11a2RRh9IXQHJWMLD9R/Pqs8uQiPk0lXDOvCromZWXROpjyYsgctVFB+sf50zPZbYlQd1uDneh1B/wA6vEq3ocfpH7SD5m3iqsMQ9KAYx6VZasusUcrOv89H76JVlzinlZnPpEfaqwSBGtxqk963/kPNVx5qele81PSrF/Bzir+ZnPpEfar34OcU/wAzufSI+1UuIFP1zSe9b/yHmq7EY9KEIx6VYf4OsVfzOv6RH2q6MusVfzOv6RH2qkJAm9c0nvW/8h5qvhFPShpinpVgjLrFOm+zr+kR9qjBl5iccbSv6RH2qkJAqjjNL71v1Hmq+TEPSlCIZ6VPk5fYlH8Uq+kR9qjkYAxGONqV9Ij99SEgVLsZpvet+o81AUwieVKW4J6VPUYCxF/NavpEfvpU3gPEI42xX0iP31MSN5oV+MU/vG/UKBtwfm0ragEkejU7bwJfgd9uP0iP30sawRfBxgaf8xH76mHt5oGTF4Ts8fUKDtW3h6NL2rZw9Gpyzgq884Wn/MR++l7WDbqOMQfSJ/fVge3ms6TEwdioOxbfm06R7bvHo1M2MI3D5bKE+Lif307R8KKRoXpLSB0SCo/5Cn4jBuVmS1znbKIRrZw9Gn6BZ3XlhDLKlnnoOHj0qR/c+zWxgvy3BsJ4rkLDaP8A576it+zTsduZVGtY8+WOAbHZsg+PP3D30PJVMbsgWxz1LrMBPZ57BSdMGBa4ypU95ohsbSipWjaPE8/0eNVZjfMkzEOwLQ4pEcjZW8dynR0Hsp/T3VCcS44ul8dJmST2aTqhlHooR4D/ADO+oRKnKWSSqgHyvl7F1eGej1nCSo1PLqHmUdPnlxRJVTE+8STvrzz5J40hccJqxjLL0OCAMFgguLJpMo0JSteJopRq8BaTWoJNAJrpNAJp1cAuA0IGgV3Wkp2RoNGJVRANDBpKBCVIXSlt2m8Ko1K6gQqHMunhuQRzpexMKedR9LmlHoe76pcy6CkgBUrZuKkj1qerbia4W1W1Bnvxj/RrIB93CoEiSRzo5MvTnVBiWZLQMkFnC4VwRc0cQMgB15iUP6Zka/FOlOSc2pun4y1w1eClj/OqTTMPtUZ56faqPDKxpPR2jebmMfLTwV1fhakfzTF+kVQfwsSD/FEX6VdUv52farwmkc6lkKq+zVF7vvPmrnOa8kD/AFRF+lXQTmxJ/miL9IuqaM0ketXPPD7VPlcnHo3Re77z5q5xmvJ0/wBURfpF178LEkfxRF+kXVMeen2q954etLIU/wBm6L3fefNXOc2ZX80RPpF0H8LUv+aIn0i6przw+1XDLPWnyuS+zdF7vvPmrn/CzL5WmJ9IuvfhZl/zTE/PXVM+dn2q954fapsrkvs3Re77z5q6Bm3NHq2mH+euu/henj+Kof56/wB9Ut54ete88PWnyu5pfZqh934+auv8ME/X/VUP85f766M4bgD/AKrhfnL/AH1Sfnh9quiYetKzuab7N0Q/2x3+au/8MtyA3WqF+cv99dGc91H8Vwfiv99Uh54farnnp9qlZ3NTHo9SDaPxV2uZ0XtQPZwYDffsrV/6qZ52a+KZKSlNwTGB5MNJT9e81VJmn2qKVLJ50srjuVfHgVM06RhSu4Yjmz3S7MmOyHPadWVH66ZnripR9amZcknnRCn9edOIgteKhYwWATg9KKjxpA69rzohT2vOiFOa1e1lloxwgIxa++k6la1wqotSqtARbWrxVRZNeJ3UAmnVwC4TQa6aDTqwBc1rorlepk6GDXQaBXdaSayMBoYVRINCCqSiQlAXRiV0mCqEDTWVZalYc3ULtO+kgXQtuo2VZYlgePWu9saR7Vd26WVQyBLO2PWvduetI9vdXts0sqXDCWdsete7Y9aR7Zr23SypcMJZ2x617tj1pHt99e2u+nypcMJYHj1r3bHrSTb769t0sqXDSvtj1rvbHrSPbr23SypuGEs7bvrnbGkm3317b76WVLhhK+2PWuh4jnSLb767tUsqXDCWdsete7Y9aR7Ve293GllS4YSrtj1oJepMVd9c2u+llUgwJQXNaLLhorboJVT2UgxGlXfRZVQdqgk06mGrpVQCa4TXCadWALxNBNc1rmtJTAXta5rXia5SUl//2Q==';
